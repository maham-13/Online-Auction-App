import 'package:cloud_firestore/cloud_firestore.dart';

class Message {
  final String senderId;
  final String text;
  final String? imageUrl;
  final Timestamp? timestamp;

  Message({
    required this.senderId,
    required this.text,
    this.imageUrl,
    this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'senderId': senderId,
      'text': text,
      'imageUrl': imageUrl,
      'timestamp': timestamp,
    };
  }

  static Message fromMap(Map<String, dynamic> map) {
    return Message(
      senderId: map['senderId'],
      text: map['text'],
      imageUrl: map['imageUrl'] ?? '',
      timestamp: map['timestamp'],
    );
  }
}
