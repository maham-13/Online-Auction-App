import 'package:cloud_firestore/cloud_firestore.dart';

class CartModel {
  final String productid;
  final String name;
  final String image;
  final Timestamp endtime;
  final int baseprice;
  final int bidprice;

  CartModel(
      {required this.productid,
      required this.name,
      required this.image,
      required this.endtime,
      required this.baseprice,
      required this.bidprice});

  factory CartModel.fromSnapShot(DocumentSnapshot snap) {
    return CartModel(
        productid: snap['productid'],
        name: snap['name'],
        image: snap['image'],
        endtime: snap['endtime'],
        baseprice: (snap['baseprice'] as num).toInt(),
        bidprice: (snap['bidprice'] as num).toInt());
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'productid': productid,
      'name': name,
      'image': image,
      'endtime': endtime,
      'baseprice': baseprice,
      'bidprice': bidprice,
    };
  }
}
