import 'package:cloud_firestore/cloud_firestore.dart';

class ChatMetadata {
  final String id;
  final String name;
  final String pic;
  final String lastMsg;
  final Timestamp lastTime;
  // String? lastimageurl;

  ChatMetadata({
    required this.id,
    required this.name,
    required this.pic,
    required this.lastMsg,
    required this.lastTime,
    // this.lastimageurl,
  });
}
