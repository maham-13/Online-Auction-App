class UserModel {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final String createdAt;
  final String deviceToken;
  final String role;
  final String userprofile;
  final Map<String, dynamic> location;
  final Map<String, String> deliveryInfo;
  final bool isblock;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.phone,
    required this.createdAt,
    required this.deviceToken,
    required this.role,
    required this.location,
    required this.userprofile,
    required this.deliveryInfo,
    this.isblock = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'phone': phone,
      'deviceToken': deviceToken,
      'createdAt': createdAt,
      'role': role,
      'userProfile': userprofile,
      'location': location,
      'deliveryInfo': deliveryInfo,
      'isblock': isblock
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
      location: map['location'] ?? '',
      userprofile: map['userProfile'] ?? '',
      deviceToken: map['deviceToken'] ?? '',
      createdAt: map['createdAt'] ?? '',
      deliveryInfo: Map<String, String>.from(map['deliveryInfo'] ?? {}),
      role: map['role'],
      isblock: map['isblock'],
    );
  }

  UserModel copyWith({
    String? uid,
    String? name,
    String? email,
    String? phone,
    String? role,
    String? userprofile,
    Map<String, dynamic>? location,
    String? createdAt,
    String? deviceToken,
    bool? isblock,
    Map<String, String>? deliveryInfo,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      role: role ?? this.role,
      userprofile: userprofile ?? this.userprofile,
      location: location ?? this.location,
      deliveryInfo: deliveryInfo ?? this.deliveryInfo,
      createdAt: createdAt ?? this.createdAt,
      deviceToken: deviceToken ?? this.deviceToken,
      isblock: isblock ?? this.isblock,
    );
  }
}
