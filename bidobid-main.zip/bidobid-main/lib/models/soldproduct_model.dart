import 'package:bidobid/models/bid_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SoldProductModel {
  final String productId;
  final String name;
  final String category;
  final String imageUrl;
  final int basePrice;
  final String ownerId;
  final String ownerEmail;
  final String ownerProfile;
  final String buyerId;
  final String buyerName;
  final String approvalStatus;
  final int soldPrice;
  final Timestamp soldDate;
  final String productInformation;
  final String deliveryInformation;
  final List<BidModel> bids; // List of bids

  SoldProductModel({
    required this.productId,
    required this.name,
    required this.category,
    required this.imageUrl,
    required this.basePrice,
    required this.ownerId,
    required this.ownerEmail,
    required this.ownerProfile,
    required this.buyerId,
    required this.buyerName,
    required this.approvalStatus,
    required this.soldPrice,
    required this.soldDate,
    required this.productInformation,
    required this.deliveryInformation,
    required this.bids,
  });

  factory SoldProductModel.fromSnapshot(
      DocumentSnapshot snap, List<BidModel> bidsList) {
    return SoldProductModel(
      productId: snap.id,
      name: snap['name'],
      category: snap['category'],
      imageUrl: snap['imageUrl'],
      basePrice: (snap['baseprice'] as num).toInt(),
      ownerId: snap['ownerId'],
      ownerEmail: snap['ownerEmail'],
      ownerProfile: snap['ownerProfile'] ?? '',
      buyerId: snap['highestbidid'],
      buyerName: snap['bidwinnerName'] ?? '',
      approvalStatus: snap['approvalStatus'] ?? '',
      soldPrice: (snap['highestbidamount'] as num).toInt(),
      soldDate: snap['endDate'],
      productInformation: snap['productInformation'],
      deliveryInformation: snap['deliveryInformation'],
      bids: bidsList, // Assigning fetched bids list
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'name': name,
      'category': category,
      'imageUrl': imageUrl,
      'basePrice': basePrice,
      'ownerId': ownerId,
      'ownerEmail': ownerEmail,
      'ownerProfile': ownerProfile,
      'buyerId': buyerId,
      'buyerName': buyerName,
      'soldPrice': soldPrice,
      'soldDate': soldDate,
      'productInformation': productInformation,
      'deliveryInformation': deliveryInformation,
      'bids': bids
          .map((bid) => bid.toBidMap())
          .toList(), // Convert list of bids to map
    };
  }
}
