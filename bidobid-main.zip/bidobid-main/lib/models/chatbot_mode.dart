import 'dart:convert';

class GetConnectionModal {
  final String id;
  final String provider;
  final String model;
  final String object;
  final int created;
  final List<Choice> choices;
  final Usage usage;

  GetConnectionModal({
    required this.id,
    required this.provider,
    required this.model,
    required this.object,
    required this.created,
    required this.choices,
    required this.usage,
  });

  factory GetConnectionModal.fromRawJson(String str) =>
      GetConnectionModal.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory GetConnectionModal.fromJson(Map<String, dynamic> json) =>
      GetConnectionModal(
        id: json["id"],
        provider: json["provider"],
        model: json["model"],
        object: json["object"],
        created: json["created"],
        choices:
            List<Choice>.from(json["choices"].map((x) => Choice.fromJson(x))),
        usage: Usage.fromJson(json["usage"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "provider": provider,
        "model": model,
        "object": object,
        "created": created,
        "choices": List<dynamic>.from(choices.map((x) => x.toJson())),
        "usage": usage.toJson(),
      };
}

class Choice {
  final dynamic logprobs;
  final String finishReason;
  final String nativeFinishReason;
  final int index;
  final Message message;

  Choice({
    required this.logprobs,
    required this.finishReason,
    required this.nativeFinishReason,
    required this.index,
    required this.message,
  });

  factory Choice.fromRawJson(String str) => Choice.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Choice.fromJson(Map<String, dynamic> json) => Choice(
        logprobs: json["logprobs"],
        finishReason: json["finish_reason"],
        nativeFinishReason: json["native_finish_reason"],
        index: json["index"],
        message: Message.fromJson(json["message"]),
      );

  Map<String, dynamic> toJson() => {
        "logprobs": logprobs,
        "finish_reason": finishReason,
        "native_finish_reason": nativeFinishReason,
        "index": index,
        "message": message.toJson(),
      };
}

class Message {
  final String role;
  final String content;
  final dynamic refusal;
  final String reasoning;

  Message({
    required this.role,
    required this.content,
    required this.refusal,
    required this.reasoning,
  });

  factory Message.fromRawJson(String str) => Message.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Message.fromJson(Map<String, dynamic> json) => Message(
        role: json["role"],
        content: json["content"],
        refusal: json["refusal"],
        reasoning: json["reasoning"],
      );

  Map<String, dynamic> toJson() => {
        "role": role,
        "content": content,
        "refusal": refusal,
        "reasoning": reasoning,
      };
}

class Usage {
  final int promptTokens;
  final int completionTokens;
  final int totalTokens;

  Usage({
    required this.promptTokens,
    required this.completionTokens,
    required this.totalTokens,
  });

  factory Usage.fromRawJson(String str) => Usage.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Usage.fromJson(Map<String, dynamic> json) => Usage(
        promptTokens: json["prompt_tokens"],
        completionTokens: json["completion_tokens"],
        totalTokens: json["total_tokens"],
      );

  Map<String, dynamic> toJson() => {
        "prompt_tokens": promptTokens,
        "completion_tokens": completionTokens,
        "total_tokens": totalTokens,
      };
}
