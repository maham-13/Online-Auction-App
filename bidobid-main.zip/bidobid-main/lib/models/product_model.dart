// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';

class Product {
  final String productid;
  final String name;
  final String category;
  final String imageUrl;
  final int baseprice;
  final bool isRecommended;
  final bool isPopular;
  final String ownerEmail;
  final String ownerName;
  final String ownerId;
  final String ownerProfile;
  final Timestamp endDate;
  final String productInformation;
  final String deliveryInformation;
  final String approvalStatus;
  final String highestbidid;
  final int highestbidamount;
  final String bidwinnerName;
  final String status;
  const Product({
    required this.productid,
    required this.name,
    required this.category,
    required this.imageUrl,
    required this.baseprice,
    required this.isRecommended,
    required this.isPopular,
    required this.ownerEmail,
    required this.ownerName,
    required this.ownerId,
    required this.ownerProfile,
    required this.endDate,
    required this.productInformation,
    required this.deliveryInformation,
    required this.approvalStatus,
    required this.highestbidid,
    required this.highestbidamount,
    required this.bidwinnerName,
    required this.status,
  });

  factory Product.fromSnapshot(DocumentSnapshot snap) {
    Product product = Product(
      productid: snap.id,
      name: snap['name'],
      category: snap['category'],
      imageUrl: snap['imageUrl'],
      baseprice: (snap['baseprice'] as num).toInt(),
      isRecommended: snap['isRecommended'],
      isPopular: snap['isPopular'],
      deliveryInformation: snap['deliveryInformation'],
      productInformation: snap['productInformation'],
      ownerEmail: snap['ownerEmail'],
      ownerName: snap['ownerName'],
      ownerId: snap['ownerId'] ?? '',
      ownerProfile: snap['ownerProfile'] ?? '',
      endDate: snap['endDate'],
      approvalStatus: snap['approvalStatus'] ?? 'pending',
      highestbidid: snap['highestbidid'] ?? '',
      highestbidamount: (snap['highestbidamount'] as num).toInt(),
      bidwinnerName: snap['bidwinnerName'] ?? '',
      status: snap['status'] ?? 'active',
    );
    return product;
  }

  Product copyWith({
    String? productid,
    String? name,
    String? category,
    String? imageUrl,
    int? baseprice,
    bool? isRecommended,
    bool? isPopular,
    String? ownerEmail,
    String? ownerName,
    String? ownerId,
    String? ownerProfile,
    Timestamp? endDate,
    String? productInformation,
    String? deliveryInformation,
    String? approvalStatus,
    String? highestbidid,
    int? highestbidamount,
    String? status,
    String? bidwinnerName,
  }) {
    return Product(
      productid: productid ?? this.productid,
      name: name ?? this.name,
      category: category ?? this.category,
      imageUrl: imageUrl ?? this.imageUrl,
      baseprice: baseprice ?? this.baseprice,
      isRecommended: isRecommended ?? this.isRecommended,
      isPopular: isPopular ?? this.isPopular,
      ownerEmail: ownerEmail ?? this.ownerEmail,
      ownerName: ownerName ?? this.ownerName,
      ownerId: ownerId ?? this.ownerId,
      ownerProfile: ownerProfile ?? this.ownerProfile,
      endDate: endDate ?? this.endDate,
      productInformation: productInformation ?? this.productInformation,
      deliveryInformation: deliveryInformation ?? this.deliveryInformation,
      approvalStatus: approvalStatus ?? this.approvalStatus,
      highestbidid: highestbidid ?? this.highestbidid,
      highestbidamount: highestbidamount ?? this.highestbidamount,
      status: status ?? this.status,
      bidwinnerName: bidwinnerName ?? this.bidwinnerName,
    );
  }

  Map<String, dynamic> toProductMap() {
    return <String, dynamic>{
      'name': name,
      'category': category,
      'imageUrl': imageUrl,
      'baseprice': baseprice,
      'isRecommended': isRecommended,
      'isPopular': isPopular,
      'deliveryInformation': deliveryInformation,
      'productInformation': productInformation,
      'ownerEmail': ownerEmail,
      'ownerName': ownerName,
      'ownerId': ownerId,
      'ownerProfile': ownerProfile,
      'endDate': endDate,
      'approvalStatus': approvalStatus,
      'highestbidid': highestbidid,
      'highestbidamount': highestbidamount,
      'bidwinnerName': bidwinnerName,
      'status': status,
    };
  }
}
