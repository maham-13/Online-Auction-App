import 'package:cloud_firestore/cloud_firestore.dart';

class BidModel {
  final String userId;
  final String userProfile;
  final String userName;
  final String userFcmToken;
  final String productId;
  final String productName;
  final int bidAmount;
  final DateTime endTime;
  final String status;

  BidModel({
    required this.userId,
    required this.userProfile,
    required this.userFcmToken,
    required this.userName,
    required this.productId,
    required this.productName,
    required this.bidAmount,
    required this.endTime,
    required this.status,
  });

  factory BidModel.fromSnapshot(Map<String, dynamic> snapshot) {
    return BidModel(
        userId: snapshot['userId'],
        userProfile: snapshot['userProfile'] ?? '',
        userFcmToken: snapshot['userFcmToken'] ?? '',
        userName: snapshot['userName'] ?? '',
        productId: snapshot['productId'] ?? '',
        productName: snapshot['productName'] ?? '',
        bidAmount: snapshot['bidAmount'] ?? 0,
        endTime: (snapshot['endTime'] as Timestamp).toDate(),
        status: snapshot['status'] ?? 'active');
  }

  Map<String, dynamic> toBidMap() {
    return <String, dynamic>{
      'userId': userId,
      'userProfile': userProfile,
      'userFcmToken': userFcmToken,
      'userName': userName,
      'productId': productId,
      'productName': productName,
      'bidAmount': bidAmount,
      'endTime': endTime,
      'timeStamp': FieldValue.serverTimestamp(),
      'status': status,
    };
  }
}
