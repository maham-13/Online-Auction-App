import 'package:bidobid/pages/Chat/chat_list_page.dart';
import 'package:bidobid/pages/Cart/cart_page.dart';
import 'package:bidobid/pages/Home/home_page.dart';
import 'package:bidobid/pages/Product/add_product.dart';
import 'package:flutter/material.dart';
import '../pages/Account/profile_page.dart';

class Navbar extends StatefulWidget {
  const Navbar({super.key});

  @override
  State<Navbar> createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  int _selectedIndex = 0;

  void _navigateBottomBar(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  //LIST OF PAGES
  final List<Widget> _pages = [
    const UserHome(),
    // const UserChat(),
    const ChatListScreen(),
    const UserAddProduct(),
    const UserCart(),
    const UserProfile(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.grey[200],
        currentIndex: _selectedIndex,
        onTap: _navigateBottomBar,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.deepPurple,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.pentagon_outlined),
            activeIcon: Icon(
              Icons.pentagon_rounded,
              size: 26,
            ),
            label: 'Home',
            backgroundColor: Colors.amber,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.message_outlined),
            activeIcon: Icon(
              Icons.message,
              size: 26,
            ),
            label: 'Chat',
            backgroundColor: Colors.amber,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            activeIcon: Icon(
              Icons.add_circle,
              size: 26,
            ),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart_outlined),
            activeIcon: Icon(
              Icons.shopping_cart_rounded,
              size: 26,
            ),
            label: 'Cart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outlined),
            activeIcon: Icon(
              Icons.person,
              size: 26,
            ),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
