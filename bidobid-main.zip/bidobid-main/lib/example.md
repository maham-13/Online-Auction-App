Future<SoldProduct?> fetchSoldProduct(String productId) async {
  try {
    // Fetch product details
    DocumentSnapshot productSnap = 
        await FirebaseFirestore.instance.collection('products').doc(productId).get();

    if (!productSnap.exists) return null;

    // Fetch all bids for this product
    QuerySnapshot bidSnap = await FirebaseFirestore.instance
        .collection('products')
        .doc(productId)
        .collection('bids')
        .get();

    List<BidModel> bidList = bidSnap.docs
        .map((doc) => BidModel.fromSnapshot(doc.data() as Map<String, dynamic>))
        .toList();

    return SoldProduct.fromSnapshot(productSnap, bidList);
  } catch (e) {
    print('Error fetching sold product: $e');
    return null;
  }
}
