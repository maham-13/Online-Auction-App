import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class LocationService {
  static Future<Map<String, dynamic>?> getUserCountry(
      BuildContext context) async {
    while (true) {
      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        bool accepted = await showLocationDialog(context);
        if (!accepted) {
          continue;
        }
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          continue;
        }
      }

      try {
        Position position = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ));
        List<Placemark> placemarks = await placemarkFromCoordinates(
            position.latitude, position.longitude);

        Placemark? place = placemarks.first;

        Map<String, dynamic> locationData = {
          "latitude": position.latitude,
          "longitude": position.longitude,
          "country": place.country ?? "Unknown",
          "city": place.locality ?? "Unknown",
          "street": place.street ?? "Unknown",
          "subThoroughfare": place.subThoroughfare ?? "Unknown",
          "subAdministrativeArea": place.subAdministrativeArea ?? "Unknown",
          "postalcode": place.postalCode ?? "Unknown",
          "thoroughfare": place.thoroughfare ?? "Unknown",
        };

        log("Location Data: $locationData");

        if (place.country != "Pakistan") {
          await showNotAllowedDialog(context);
          continue;
        }

        return locationData;
      } catch (e) {
        print("Error getting location: $e");
        return null;
      }
    }
  }

  static Future<bool> showLocationDialog(BuildContext context) async {
    return await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            title: const Text("Location Permission Required"),
            content: const Text(
                "This app requires location permission to verify that you are in Pakistan."),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
                child: const Text("Cancel"),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
                child: const Text("Grant Permission"),
              ),
            ],
          ),
        ) ??
        false;
  }

  static Future<void> showNotAllowedDialog(BuildContext context) async {
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text("Access Denied"),
        content: const Text("Only users from Pakistan can use this app."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }
}
