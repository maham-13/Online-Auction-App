import 'dart:convert';
import 'dart:math';
import 'package:bidobid/services/serverkey_service.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;

class NotificationServices {
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    await requestNotificationPermission();
    firebaseInit();
    isTokenRefresh();

    messaging.getToken().then((value) {
      if (kDebugMode) {
        print("Device Token: $value");
      }
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print("Foreground Notification: ${message.notification?.title}");
      showNotification(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print("App Opened from Notification: ${message.notification?.title}");
    });
  }

  Future<void> requestNotificationPermission() async {
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      carPlay: true,
      criticalAlert: true,
      provisional: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    }

    if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      print('User granted provisional permission');
    } else {
      // AppSettings.openAppSettings();
    }
  }

  void initLocalNotifications(
      BuildContext context, RemoteMessage message) async {
    const androidInitializationSettings =
        AndroidInitializationSettings("@mipmap/ic_launcher");

    const iosInitializationSettings = DarwinInitializationSettings();

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: androidInitializationSettings,
      iOS: iosInitializationSettings,
    );

    // request notification permissions for android 13 or above
    _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()!
        .requestNotificationsPermission();

    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (details) {},
      onDidReceiveBackgroundNotificationResponse: (details) {},
    );
  }

  Future<void> showNotification(RemoteMessage message) async {
    AndroidNotificationChannel channel = AndroidNotificationChannel(
      Random.secure().nextInt(100000).toString(),
      'High Importance Notifications',
      importance: Importance.high,
      playSound: true,
      showBadge: true,
      enableLights: true,
      enableVibration: true,
      // sound: RawResourceAndroidNotificationSound('notification')
    );

    AndroidNotificationDetails androidNotificationDetails =
        AndroidNotificationDetails(
      channel.id.toString(),
      channel.name.toString(),
      channelDescription: 'Your channel description',
      icon: '@mipmap/ic_launcher',
      importance: Importance.high,
      color: Colors.blue,
      ticker: 'ticker',
      playSound: true,
      enableVibration: true,
      enableLights: true,
      // sound: RawResourceAndroidNotificationSound('notification'),
    );

    Future.delayed(
      Duration.zero,
      () {
        _flutterLocalNotificationsPlugin.show(
            0,
            message.notification!.title,
            message.notification!.body,
            NotificationDetails(android: androidNotificationDetails));
      },
    );
  }

  void firebaseInit() {
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  }

  static Future<void> _firebaseMessagingBackgroundHandler(
      RemoteMessage message) async {
    if (kDebugMode) {
      print("Background Message Received: ${message.notification?.title}");
    }
  }

  Future<String> getDeviceToken() async {
    String? token = await messaging.getToken();
    return token!;
  }

  void isTokenRefresh() async {
    messaging.onTokenRefresh.listen(
      (event) {
        event.toString();
        print("refresh");
      },
    );
  }

  Future<void> sendPushNotification(
      String deviceToken, String title, String body) async {
    ServerKeyService getServerKey = ServerKeyService();
    String serverKey = await getServerKey.server_token();
    final response = await http.post(
      Uri.parse(
          "https://fcm.googleapis.com/v1/projects/quizmaster-acdee/messages:send"),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $serverKey',
      },
      body: jsonEncode(<String, dynamic>{
        "message": {
          "token": deviceToken,
          "notification": {"title": title, "body": body},
          "data": {"click_action": "FLUTTER_NOTIFICATION_CLICK"}
        }
      }),
    );

    if (response.statusCode == 200) {
      if (kDebugMode) {
        print("Notification sent successfully");
      }
    } else {
      if (kDebugMode) {
        print(
            "Failed to send notification: ${response.statusCode} ${response.body}");
      }
    }
  }
}
