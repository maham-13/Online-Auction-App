import 'package:googleapis_auth/auth_io.dart';

class ServerKeyService {
  Future<String> server_token() async {
    final scopes = [
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/firebase.database',
      'https://www.googleapis.com/auth/firebase.messaging',
    ];
    final client = await clientViaServiceAccount(
        ServiceAccountCredentials.fromJson({
          "type": "service_account",
          "project_id": "quizmaster-acdee",
          "private_key_id": "4e17d031df5b4e702e3319fbb755935fddbed674",
          "private_key":
              "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCkxgDGMTA3qBMo\ndWCNiK00ge2CPK0eEpB/1IMJ7odSCMsy83u8csNiGzH96owIt5abJZxRQfs1WTEe\nRjChWwSArY/64tuZMQHCWIe9+5QWlH3My1cOnKxNbcJHClxsktCDXBxpTWMQs/L6\nbXI3zvbtE5lPX0/itlp7/TTMrd+Y4QpDrOA1N7tnwnew2wANwNev8iLPunyF6DwF\n19RHnlFjZ3J5BlgVvP+lG91xFhBvsdwUAcVBptTbI4xW41XAh0z9czIyLXKLrCA3\n32q6ggRV2b1d7Bnw1hGMyWPOBMU29xyBGh43+JQRlzp8hG3Zk/KsnHpf4oK/xfmF\nj/PxsXKrAgMBAAECggEARkSsetjqO6oBNY1M9j7VwqEwFQzkNQFsvx71HQysh8b5\nRQrB930nppR7btISEvucDiDtd1fAliEpycPcJEuo8WlTEAaj6MIWAnf3t4Tsw+5i\nca47u58D+ec3ZU1dWe4IXySudxfKCgr7sWFwRq2L71Ge3VMDwebLUroKRMlXpB2Q\n7eCeP/5KrG4jBkw19OrhIYleo6GhXFdC3suQkTek1dlQxpxV0eI3tKSjB+a0akL7\nEQg2TWIJi1H6xWRou2gVv4bSdo9IKnvU0ezkbMNCAQJIDMRXZ1dvVT13tGJJKBzi\nMU5Dbdo+nLaQuDoLC4c5bhP5Kpm+F548nuE4w0w4SQKBgQDZFU2qwEXyDRIvEGGv\nNFTmbNuhSs882VClTvSBA/3lltSQ0X8O0iOYusTBTvD1TMayXnctpRgdOW9+OEHc\nIQAg2aYKeM+cBV+84Ue59HmR6+raPZQYaYhCn33ZbM0mx5snUjqCf/f8pmdbd5pa\nB924Wt0JZfH+V+opMQPB1ic9UwKBgQDCUAYz6r4S6xtY6dTxTaHf08wo2m+hIjqn\nBdKEuVc1A9ZjKNlGfJYDGUovF/djE7gSWOJC41OrgWkcD9hoxoui6HuE92TR+ESe\nKgKj/o5MwXz3qXYBzAyLN3/qjtna7mK4KfuLELsULJxgrT1mmEOnbnk5sTeFfzoD\nu8PlA8ZySQKBgQCKmzyU+uFuNIRYwpfsm3heDEGL0c1Sp9sDQc+CFP9nOZANy4XZ\n+7i4yv/YAcR+i4AO4Zws683i0wpqSBddK0D+uJl49Dxy/UdsvVbj18JLtpukr07A\n65kSGO3tBrhSu35IdAthyb2YdtNlpo9KTt112aZqWspRwOaFWINyn388ewKBgQCe\nfMLyaY7qw1Sk6uRChP15ILkuwSu3k8GfJYKVus5EcYLVkiXV9hwtHt2BF90xtI24\neULjJ6PBCWZ/+vSaUQbnsxO8WkSjdgoRr1ZECIZsWIzjPBcCVDoO+w+cczOB/FoM\nuEFxJg5Q4CoUOHkSSzMzR0odIkyU2DargOTA0Jl18QKBgH0gYnqavuHU0q6pbCtU\nGTdxkJQQbFiMb5L89qUALGvmxTN51ry3K+NS+jg0JbWlp6nHEitaQaT8ViLROIA7\nUrZau8x13427yluvXGUZtvcWNpyVf789PWOGOCV8Myyzsw6tgwdvvbVoM/smRLbu\n8TysU3ruPJu42le3IPHBsWP5\n-----END PRIVATE KEY-----\n",
          "client_email":
              "firebase-adminsdk-sdebu@quizmaster-acdee.iam.gserviceaccount.com",
          "client_id": "108501673983447084723",
          "auth_uri": "https://accounts.google.com/o/oauth2/auth",
          "token_uri": "https://oauth2.googleapis.com/token",
          "auth_provider_x509_cert_url":
              "https://www.googleapis.com/oauth2/v1/certs",
          "client_x509_cert_url":
              "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-sdebu%40quizmaster-acdee.iam.gserviceaccount.com",
          "universe_domain": "googleapis.com"
        }),
        scopes);
    final accessserverkey = client.credentials.accessToken.data;
    return accessserverkey;
  }
}
