import 'dart:developer';
import 'dart:io';

import 'package:bidobid/pages/Chat/provider/chat_provider.dart';
import 'package:bidobid/models/messagemodal.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

class SendChatPage extends ConsumerWidget {
  final String senderId;
  final String senderName;
  final String senderPic;
  final String receiverId;
  final String receiverName;
  final String receiverPic;

  SendChatPage({
    super.key,
    required this.senderId,
    required this.senderName,
    required this.senderPic,
    required this.receiverId,
    required this.receiverName,
    required this.receiverPic,
  });

  final TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chatnotifierlistner = ref.watch(chatProvider.notifier);
    final ImagePicker pickerImage = ImagePicker();
    XFile? selectImage;
    String uploadimageUrl = "";
    final FirebaseStorage storage = FirebaseStorage.instance;
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(receiverName.toUpperCase(),
            style: GoogleFonts.outfit(
                color: Colors.white, fontWeight: FontWeight.w600)),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: StreamBuilder<List<Message>>(
                stream: chatnotifierlistner.getMessages(
                    receiverId: receiverId, senderId: senderId),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(child: Text("No messages yet."));
                  }
                  final messages = snapshot.data!;
                  return ListView.builder(
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final message = messages[index];
                      bool isSentByMe = message.senderId == senderId;

                      return Column(
                        children: [
                          Row(
                            mainAxisAlignment: isSentByMe
                                ? MainAxisAlignment.end
                                : MainAxisAlignment.start,
                            children: [
                              if (!isSentByMe)
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: CircleAvatar(
                                    backgroundImage: receiverPic != ""
                                        ? CachedNetworkImageProvider(
                                            receiverPic)
                                        : const AssetImage(
                                            "assets/images/avater.png"),
                                  ),
                                ),

                              // if (message.imageUrl!.isNotEmpty)
                              //   CachedNetworkImage(
                              //     imageUrl: message.imageUrl!,
                              //     // width: 50,
                              //     height: 150,
                              //     fit: BoxFit.cover,
                              //     placeholder: (context, url) =>
                              //         const CircularProgressIndicator(),
                              //     errorWidget: (context, url, error) =>
                              //         const Icon(Icons.error),
                              //   ),
                              Container(
                                constraints: BoxConstraints(
                                  maxWidth: MediaQuery.of(context).size.width *
                                      0.7, // Limit the width
                                ),
                                decoration: BoxDecoration(
                                  color: isSentByMe
                                      ? Colors.deepPurple
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: message.imageUrl != ""
                                    ? Container(
                                        constraints: BoxConstraints(
                                          maxWidth: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.7,
                                        ),
                                        child: Column(
                                          children: [
                                            ClipRRect(
                                              borderRadius: BorderRadius.circular(12),
                                              child: CachedNetworkImage(
                                                imageUrl: message.imageUrl!,
                                                width: 150,
                                                height: 150,
                                                fit: BoxFit.fill,
                                                placeholder: (context, url) =>
                                                    Container(
                                                  color:
                                                      Colors.black.withAlpha(1),
                                                ),
                                                errorWidget:
                                                    (context, url, error) =>
                                                        const Icon(Icons.error),
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 8.0),
                                              child: Text(
                                                message.text,
                                                style: GoogleFonts.inter(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w500,
                                                  color: isSentByMe
                                                      ? Colors.white
                                                      : Colors.black,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 20, vertical: 15.0),
                                        child: Text(
                                          message.text,
                                          style: GoogleFonts.inter(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500,
                                              color: isSentByMe
                                                  ? Colors.white
                                                  : Colors.black),
                                        ),
                                      ),
                              ),
                              if (isSentByMe)
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: CircleAvatar(
                                    backgroundImage: senderPic != ""
                                        ? CachedNetworkImageProvider(senderPic)
                                        : const AssetImage(
                                            "assets/images/avater.png"),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 20),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: messageController,
                    style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Colors.black),
                    decoration: InputDecoration(
                        hintText: "Type here...",
                        hintStyle: GoogleFonts.inter(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                          borderSide:
                              const BorderSide(color: Color(0xFFBFBDBD)),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding: const EdgeInsets.only(left: 16.0),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(25),
                            borderSide:
                                const BorderSide(color: Color(0xFFBFBDBD))),
                        prefixIcon: IconButton(
                          onPressed: () {
                            showModalBottomSheet(
                              backgroundColor: Colors.white,
                              context: context,
                              builder: (context) {
                                return SafeArea(
                                  child: Wrap(
                                    children: [
                                      ListTile(
                                        leading: const Icon(Icons.camera_alt),
                                        title: const Text("Camera"),
                                        onTap: () async {
                                          selectImage =
                                              await pickerImage.pickImage(
                                                  source: ImageSource.camera);

                                          // Navigator.pop(context);
                                        },
                                      ),
                                      ListTile(
                                        leading:
                                            const Icon(Icons.photo_library),
                                        title: const Text("Gallery"),
                                        onTap: () async {
                                          selectImage =
                                              await pickerImage.pickImage(
                                                  source: ImageSource.gallery);
                                          // Navigator.pop(context);
                                        },
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                          icon: const Icon(
                            Icons.link,
                            color: Colors.deepPurple,
                          ),
                        ),
                        suffixIcon: IconButton(
                          style: IconButton.styleFrom(
                              backgroundColor: Colors.deepPurple,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20.0))),
                          onPressed: () async {
                            final messageText = messageController.text.trim();
                            if (selectImage != null) {
                              uploadimageUrl = await uploadImage(selectImage!);
                            }
                            if (messageText.isNotEmpty ||
                                uploadimageUrl != "") {
                              chatnotifierlistner.sendMessage(
                                imageUrl: uploadimageUrl ?? '',
                                messageText: messageText,
                                senderId: senderId,
                                receiverName: receiverName,
                                receiverId: receiverId,
                                senderName: senderName,
                                receiverPic: receiverPic,
                                senderPic: senderPic,
                              );
                              messageController.clear();
                            }
                            //  else if (uploadimageUrl != "" &&
                            //     messageText.isNotEmpty) {
                            //   chatnotifierlistner.sendMessage(
                            //     imageUrl: uploadimageUrl,
                            //     messageText: messageText,
                            //     senderId: senderId,
                            //     receiverName: receiverName,
                            //     receiverId: receiverId,
                            //     senderName: senderName,
                            //     receiverPic: receiverPic,
                            //     senderPic: senderPic,
                            //   );
                            //   messageController.clear();
                            // }
                          },
                          icon: Transform.rotate(
                              angle: 5.7,
                              alignment: Alignment.center,
                              child: const Icon(
                                Icons.send_rounded,
                                color: Colors.white,
                                size: 24,
                              )),
                        )),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<String> uploadImage(XFile image) async {
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('chat_images/${DateTime.now().millisecondsSinceEpoch}');
      await storageRef.putFile(File(image.path));
      String downloadUrl = await storageRef.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      log("Error uploading image: $e");
      return '';
    }
  }
}
