import 'dart:developer';
import 'package:bidobid/models/messagemodal.dart';
import 'package:bidobid/services/notification_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

final NotificationServices notificationServices = NotificationServices();

final chatProvider = StateNotifierProvider<ChatNotifier, List<Message>>((ref) {
  return ChatNotifier();
});

class ChatNotifier extends StateNotifier<List<Message>> {
  ChatNotifier() : super([]);

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> sendMessage({
    required String messageText,
    String? imageUrl,
    required String senderId,
    required String senderName,
    required String senderPic,
    required String receiverId,
    required String receiverName,
    required String receiverPic,
  }) async {
    String chatId = _getChatId(senderId, receiverId);

    final message = Message(
      senderId: senderId,
      text: messageText,
      timestamp: Timestamp.now(),
    );
    log("is this wokring");
    try {
      await _firestore
          .collection('messages')
          .doc(chatId)
          .collection('msglist')
          .add({
        'addtime': Timestamp.now(),
        'content': messageText,
        'imageurl': imageUrl ?? '',
        'send_uid': senderId,
      });

      await _firestore.collection('messages').doc(chatId).set({
        'sender_id': receiverId,
        'receiver_id': senderId,
        'last_msg': messageText,
        'last_imageurl': imageUrl ?? '',
        'last_time': Timestamp.now(),
        'receiver_pic': receiverPic,
        'receiver_name': senderName,
        'sender_name': receiverName,
        'sender_pic': senderPic,
      }, SetOptions(merge: true));

      state = [...state, message];
      DocumentSnapshot userDoc =
          await _firestore.collection("users").doc(receiverId).get();
      String? receiverToken = userDoc['deviceToken'];

      if (receiverToken != null) {
        await notificationServices.sendPushNotification(
            receiverToken, senderName, messageText);
      }
    } catch (e) {
      log("Error sending message: $e");
    }
  }

  String _getChatId(String userId1, String userId2) {
    return userId1.hashCode <= userId2.hashCode
        ? '$userId1-$userId2'
        : '$userId2-$userId1';
  }

  Stream<List<Message>> getMessages(
      {required String senderId, required String receiverId}) {
    String chatId = _getChatId(senderId, receiverId);
    return _firestore
        .collection('messages')
        .doc(chatId)
        .collection('msglist')
        .orderBy('addtime', descending: false)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return Message(
          senderId: doc['send_uid'],
          text: doc['content'],
          imageUrl: doc['imageurl'],
          timestamp: doc['addtime'],
        );
      }).toList();
    });
  }
}
