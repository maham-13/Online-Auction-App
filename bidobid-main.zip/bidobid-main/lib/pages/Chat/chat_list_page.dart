import 'dart:developer';
import 'package:bidobid/pages/Chat/send_chat_page.dart';
import 'package:bidobid/models/chat_metadata.dart';
import 'package:bidobid/pages/Authentication/provider/auth_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';

class ChatListScreen extends ConsumerStatefulWidget {
  const ChatListScreen({super.key});

  @override
  _ChatListScreenState createState() => _ChatListScreenState();
}

class _ChatListScreenState extends ConsumerState<ChatListScreen> {
  TextEditingController searchController = TextEditingController();
  String searchQuery = '';
  List<String> selectedChatIds = [];
  @override
  void initState() {
    super.initState();

    searchController.addListener(() {
      setState(() {
        searchQuery = searchController.text.toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  String timeAgo(Timestamp timestamp) {
    final DateTime messageTime = timestamp.toDate();
    final DateTime now = DateTime.now();
    final Duration difference = now.difference(messageTime);

    if (difference.inDays > 0) {
      return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    } else {
      return 'Just now';
    }
  }

  void _toggleSelection(String chatId) {
    setState(() {
      if (selectedChatIds.contains(chatId)) {
        selectedChatIds.remove(chatId);
      } else {
        selectedChatIds.add(chatId);
      }
    });
  }

  String _getChatId(String userId1, String userId2) {
    return userId1.hashCode <= userId2.hashCode
        ? '$userId1-$userId2'
        : '$userId2-$userId1';
  }

  void _deleteChat(List<String> chatIds, String currentUserId) async {
    FirebaseFirestore firestore = FirebaseFirestore.instance;

    for (String chatId in chatIds) {
<<<<<<< HEAD
=======
      // Generate correct chat ID (assuming chatId is the user ID of the chat partner)
>>>>>>> b298d40d3051f41685e80c66f41fa2593fdb0681
      String finalChatId = _getChatId(currentUserId, chatId);

      // Reference to the messages subcollection
      CollectionReference msgCollection = firestore
          .collection('messages')
          .doc(finalChatId)
          .collection("msglist");

<<<<<<< HEAD
      QuerySnapshot msgDocs = await msgCollection.get();

=======
      // Fetch all messages inside msglist subcollection
      QuerySnapshot msgDocs = await msgCollection.get();

      // Delete each document inside msglist subcollection
>>>>>>> b298d40d3051f41685e80c66f41fa2593fdb0681
      for (var doc in msgDocs.docs) {
        await doc.reference.delete();
      }

<<<<<<< HEAD
=======
      // Delete the main chat document
>>>>>>> b298d40d3051f41685e80c66f41fa2593fdb0681
      await firestore.collection('messages').doc(finalChatId).delete();
    }

    setState(() {
<<<<<<< HEAD
      selectedChatIds.clear();
=======
      selectedChatIds.clear(); // Clear selected chats after deletion
>>>>>>> b298d40d3051f41685e80c66f41fa2593fdb0681
    });

    print("All selected chats deleted successfully");
  }

  @override
  Widget build(BuildContext context) {
    final userinfo = ref.watch(authProvider);
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.deepPurple,
        title: Text(
          "Message",
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        actions: [
          if (selectedChatIds.isNotEmpty)
            IconButton(
              onPressed: () => _deleteChat(selectedChatIds, userinfo!.uid),
              icon: const Icon(Icons.delete, color: Colors.white),
            ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextFormField(
              controller: searchController,
              style: GoogleFonts.outfit(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  color: Colors.black),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  hintText: 'Find Conversation',
                  hintStyle: GoogleFonts.outfit(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: const Color(0xFF20222C),
                  ),
                  suffixIcon: const Icon(
                    Icons.search,
                    color: Colors.deepPurple,
                  ),
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(16.0))),
            ),
          ),
          const SizedBox(height: 10),
          StreamBuilder<List<ChatMetadata>>(
            stream: _getChatList(userinfo!.uid),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text("No chats available."));
              }

              final chats = snapshot.data!;
              final filteredChats = chats.where((chat) {
                return chat.name.toLowerCase().contains(searchQuery);
              }).toList();
              log("donationcenterId ${userinfo.email}");
              return ListView.builder(
                shrinkWrap: true,
                itemCount: filteredChats.length,
                physics: const AlwaysScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final chat = filteredChats[index];
                  bool isSelected = selectedChatIds.contains(chat.id);
                  return Column(
                    children: [
                      InkWell(
                        onLongPress: () {
                          _toggleSelection(chat.id);
                        },
                        child: ListTile(
                          leading: Stack(
                            children: [
                              CircleAvatar(
                                backgroundImage: chat.pic != ""
                                    ? CachedNetworkImageProvider(chat.pic)
                                    : const AssetImage(
                                        "assets/images/avater.png"),
                              ),
                              if (isSelected)
                                Positioned.fill(
                                  child: CircleAvatar(
                                    // color: Colors.black.withOpacity(0.3),
                                    backgroundImage: chat.pic != ""
                                        ? CachedNetworkImageProvider(chat.pic)
                                        : const AssetImage(
                                            "assets/images/avater.png"),
                                    child: const Icon(Icons.check,
                                        color: Colors.green, size: 20),
                                  ),
                                ),
                            ],
                          ),
                          title: Text(
                            chat.name,
                            style: GoogleFonts.inter(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF20222C),
                            ),
                          ),
                          subtitle: Text(
                            overflow: TextOverflow.ellipsis,
                            chat.lastMsg,
                            style: GoogleFonts.inter(
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                              color: const Color(0xFF20222C),
                            ),
                          ),
                          trailing: Text(timeAgo(chat.lastTime)),
                          onTap: () {
                            if (selectedChatIds.isNotEmpty) {
                              _toggleSelection(chat.id);
                            } else {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => SendChatPage(
                                    receiverId: chat.id,
                                    receiverName: chat.name,
                                    receiverPic: chat.pic,
                                    senderId: userinfo.uid,
                                    senderName: userinfo.name,
                                    senderPic: userinfo.userprofile,
                                  ),
                                ),
                              );
                            }
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          width: double.infinity,
                          height: 1,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                            const Color(0xFF20222C).withOpacity(0.1),
                            const Color(0xFF20222C).withOpacity(0.2),
                            const Color(0xFF20222C).withOpacity(0.1),
                          ])),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Stream<List<ChatMetadata>> _getChatList(String userId) {
    return FirebaseFirestore.instance
        .collection('messages')
        .where(Filter.or(
          Filter('receiver_id', isEqualTo: userId),
          Filter('sender_id', isEqualTo: userId),
        ))
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        // Determine the chat partner (opposite user)
        bool isSender = doc['sender_id'] == userId;

        return ChatMetadata(
          id: isSender ? doc['receiver_id'] : doc['sender_id'],
          name: isSender ? doc['receiver_name'] : doc['sender_name'],
          pic: isSender ? doc['sender_pic'] : doc['receiver_pic'],
          lastMsg: doc['last_msg'],
          // lastimageurl: doc['last_imageurl'] ?? '',
          lastTime: doc['last_time'] as Timestamp,
        );
      }).toList();
    });
  }
}
