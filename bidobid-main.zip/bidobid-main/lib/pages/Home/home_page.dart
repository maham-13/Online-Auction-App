import 'package:bidobid/pages/Home/product_listview.dart';
import 'package:bidobid/pages/Home/provider/product_provider.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../widget/section_title.dart';

class UserHome extends ConsumerStatefulWidget {
  const UserHome({super.key});

  @override
  ConsumerState<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends ConsumerState<UserHome> {
  List<String> categories = [
    'assets/images/furniture.jpg',
    'assets/images/cloth.jpg',
    'assets/images/phone.jpg',
  ];
  @override
  Widget build(BuildContext context) {
    final productsAsync = ref.watch(approvedProductProvider);

    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        title: Text(
          'HOME PAGE',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: false,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15),
              topRight: Radius.circular(15),
            ),
          ),
          child: Column(
            children: [
              CarouselSlider(
                options: CarouselOptions(
                  aspectRatio: 1.5,
                  viewportFraction: 0.9,
                  autoPlay: true,
                  autoPlayCurve: Curves.fastOutSlowIn,
                  // enlargeStrategy: CenterPageEnlargeStrategy.height,
                  enlargeCenterPage: true,
                ),
                items: categories
                    .map((category) => Container(
                          margin: const EdgeInsets.symmetric(
                            horizontal: 5.0,
                            vertical: 20,
                          ),
                          child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(5.0)),
                              child: Stack(
                                children: <Widget>[
                                  Image.asset(category,
                                      fit: BoxFit.cover,
                                      width: double.infinity),
                                  Positioned(
                                    bottom: 0.0,
                                    left: 0.0,
                                    right: 0.0,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            Color.fromARGB(200, 0, 0, 0),
                                            Color.fromARGB(0, 0, 0, 0)
                                          ],
                                          begin: Alignment.bottomCenter,
                                          end: Alignment.topCenter,
                                        ),
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10.0, horizontal: 20.0),
                                    ),
                                  ),
                                ],
                              )),
                        ))
                    .toList(),
              ),
              productsAsync.when(
                data: (products) {
                  final recommededProducts = products
                      .where(
                        (element) => element.isRecommended,
                      )
                      .toList();

                  final popularProducts = products
                      .where(
                        (element) => element.isPopular,
                      )
                      .toList();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SectionTitle(title: 'RECOMMENDATION'),
                      recommededProducts.isEmpty
                          ? const Center(
                              child: Text("No Recommeded Products"),
                            )
                          : ProductListView(products: recommededProducts),
                      const SectionTitle(title: 'POPULAR'),
                      popularProducts.isEmpty
                          ? const Center(child: Text("No Popular Products"))
                          : ProductListView(products: popularProducts),
                    ],
                  );
                },
                error: (error, stackTrace) {
                  return const Center(
                    child: Text("SomeThing Went Wrong"),
                  );
                },
                loading: () {
                  return Container(
                    width: 110,
                    height: 120,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(8.0),
                        color: Colors.black.withOpacity(0.04)),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
