import 'package:bidobid/models/product_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final approvedProductProvider = StreamProvider<List<Product>>(
  (ref) {
    return FirebaseFirestore.instance
        .collection("products")
        .where('approvalStatus', isEqualTo: "approved")
        .snapshots()
        .map(
            (event) => event.docs.map((e) => Product.fromSnapshot(e)).toList());
  },
);
