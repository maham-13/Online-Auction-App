import 'package:bidobid/models/cart_model.dart';
import 'package:bidobid/models/product_model.dart';
import 'package:bidobid/models/wishlist_model.dart';
import 'package:bidobid/pages/Authentication/provider/auth_provider.dart';
import 'package:bidobid/pages/Cart/provider/cart_provider.dart';
import 'package:bidobid/pages/Home/product_page.dart';
import 'package:bidobid/pages/Wishlist/provider/wishlist_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class ProductListView extends ConsumerWidget {
  final List<Product> products;
  const ProductListView({super.key, required this.products});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentuser = ref.watch(authProvider);
    final wishlist = ref.watch(wishlistprovider);
    ref.read(wishlistprovider.notifier).fetchWishlistItems(currentuser!.uid);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Container(
        height: 175, // Ensure the ListView has a bounded height
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.0),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: products.length,
          shrinkWrap: true,
          itemBuilder: (context, index) {
            final product = products[index];
            final isFavourite =
                wishlist.any((item) => item.productid == product.productid);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4.0),
              child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return ProductDetailsPage(
                        product: products[index],
                      );
                    },
                  ));
                },
                child: Container(
                  width: 150, // Set a fixed width for each item
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Stack(children: [
                        SizedBox(
                          height: 100, // Define a fixed height
                          width: double.infinity,
                          child: ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(8.0),
                              topRight: Radius.circular(8.0),
                            ),
                            child: CachedNetworkImage(
                              imageUrl: product.imageUrl,
                              // width: 150,
                              fit: BoxFit.fill,
                              placeholder: (context, url) => Container(
                                color: Colors.black.withOpacity(0.04),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          top: 0,
                          right: 0,
                          child: currentuser.uid == product.ownerId
                              ? Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Colors.deepPurple,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: const Text(
                                    "Your Product",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600),
                                  ),
                                )
                              : IconButton(
                                  icon: isFavourite
                                      ? const Icon(
                                          Icons.favorite_outlined,
                                          color: Colors.red,
                                        )
                                      : const Icon(
                                          Icons.favorite_border,
                                          color: Colors.black,
                                        ),
                                  onPressed: () {
                                    if (isFavourite == false) {
                                      final wishlistitem = WishlistModel(
                                          productid: product.productid,
                                          name: product.name,
                                          image: product.imageUrl,
                                          endtime: product.endDate,
                                          baseprice: product.baseprice,
                                          bidprice: product.highestbidamount);
                                      ref
                                          .read(wishlistprovider.notifier)
                                          .addToWislist(
                                              wishlistitem: wishlistitem,
                                              userId: currentuser.uid);
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                              content: Text(
                                                  "${product.name} Added to Wishlist.")));
                                    } else {
                                      ref
                                          .read(wishlistprovider.notifier)
                                          .removeFromWishlist(
                                            product.productid,
                                            currentuser.uid,
                                          );
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                              content: Text(
                                                  "${product.name} Removed from Wishlist.")));
                                    }
                                  },
                                ),
                        ),
                      ]),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text(
                          product.name,
                          style: GoogleFonts.nunito(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Rs. ${product.baseprice.ceil().toString()}",
                                  style: GoogleFonts.nunito(
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          currentuser.uid == product.ownerId
                              ? const SizedBox.shrink()
                              : InkWell(
                                  onTap: () {
                                    final cartItem = CartModel(
                                        productid: product.productid,
                                        name: product.name,
                                        image: product.imageUrl,
                                        endtime: product.endDate,
                                        baseprice: product.baseprice,
                                        bidprice: product.highestbidamount);
                                    ref.read(cartprovider.notifier).addToCart(
                                        cartItem: cartItem,
                                        userId: currentuser.uid);
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: CircleAvatar(
                                      backgroundColor:
                                          Colors.black.withOpacity(0.8),
                                      radius: 18,
                                      child: const Icon(
                                        Icons.shopping_cart_outlined,
                                        size: 20,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                      const SizedBox(height: 4.0),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
