import 'dart:async';
import 'package:bidobid/pages/Chat/send_chat_page.dart';
import 'package:bidobid/pages/Authentication/provider/auth_provider.dart';
import 'package:bidobid/widget/hero_carousel_card.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/product_model.dart';

class ProductDetailsPage extends ConsumerStatefulWidget {
  final Product product;

  const ProductDetailsPage({super.key, required this.product});

  @override
  ConsumerState<ProductDetailsPage> createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends ConsumerState<ProductDetailsPage> {
  late DateTime endTime;
  late Timer _timer;
  String remainingTime = '';

  @override
  void initState() {
    super.initState();
    endTime = (widget.product.endDate).toDate();
    startTimer();
  }

  void startTimer() {
    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        _updateRemainingTimer();
      },
    );
  }

  void _updateRemainingTimer() {
    final now = DateTime.now();
    final difference = endTime.difference(now);
    if (difference.isNegative) {
      setState(() {
        remainingTime = "Bidding Ended";
      });
      _timer.cancel();
    } else {
      setState(() {
        remainingTime = _formatDuration(difference);
      });
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _formatDuration(Duration duration) {
    int hours = duration.inHours;
    int minutes = duration.inMinutes.remainder(60);
    int seconds = duration.inSeconds.remainder(60);
    return "$hours h : $minutes m : $seconds s";
  }

  @override
  Widget build(BuildContext context) {
    final userinfo = ref.watch(authProvider);
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        title: Text(
          widget.product.name.toString(),
          style: GoogleFonts.bebasNeue(
            color: Colors.white,
            fontSize: 30,
          ),
        ),
        elevation: 0,
        centerTitle: false,
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(15),
              topRight: Radius.circular(15),
            ),
          ),
          child: ListView(
            children: [
              CarouselSlider(
                options: CarouselOptions(
                  aspectRatio: 1.5,
                  viewportFraction: 1.0,
                  enlargeStrategy: CenterPageEnlargeStrategy.height,
                  enlargeCenterPage: true,
                ),
                items: [
                  HeroCarouselCard(product: widget.product),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Container(
                  width: double.infinity,
                  // height: 150,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.0),
                    color: Colors.black.withOpacity(0.08),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ListTile(
                            trailing: userinfo!.uid != widget.product.ownerId
                                ? IconButton(
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => SendChatPage(
                                              senderId: userinfo.uid,
                                              senderName: userinfo.name,
                                              senderPic: userinfo.userprofile,
                                              receiverId:
                                                  widget.product.ownerId,
                                              receiverName:
                                                  widget.product.ownerName,
                                              receiverPic:
                                                  widget.product.ownerProfile,
                                            ),
                                          ));
                                    },
                                    icon: const Icon(Icons.message_outlined),
                                  )
                                : null,
                            title: Row(
                              children: [
                                CircleAvatar(
                                  minRadius: 20,
                                  backgroundImage:
                                      widget.product.ownerProfile != ""
                                          ? CachedNetworkImageProvider(
                                              widget.product.ownerProfile,
                                            )
                                          : const AssetImage(
                                              "assets/images/avater.png"),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  widget.product.ownerName,
                                  style: GoogleFonts.outfit(
                                      fontSize: 16,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w600),
                                )
                              ],
                            )),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Starting price",
                                  style: GoogleFonts.outfit(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Colors.black),
                                ),
                                Text(
                                  "Rs. ${widget.product.baseprice.ceil()}",
                                  style: GoogleFonts.outfit(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Colors.black),
                                ),
                                widget.product.bidwinnerName != ""
                                    ? Text(
                                        "Bid Winner",
                                        style: GoogleFonts.outfit(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Colors.black),
                                      )
                                    : const SizedBox.shrink(),
                                widget.product.bidwinnerName != ""
                                    ? Text(
                                        "Name: ${widget.product.bidwinnerName}",
                                        style: GoogleFonts.outfit(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                            color: Colors.black),
                                      )
                                    : const SizedBox.shrink(),
                              ],
                            ),
                            Container(
                              color: Colors.grey,
                              width: 1,
                              height: 80,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Current Bid Price",
                                  style: GoogleFonts.outfit(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Colors.black),
                                ),
                                Text(
                                  "Rs. ${widget.product.highestbidamount.ceil()}",
                                  style: GoogleFonts.outfit(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Colors.black),
                                ),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.access_time_filled_outlined,
                                      size: 18,
                                      color: Colors.deepPurple,
                                    ),
                                    Text(remainingTime)
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: ExpansionTile(
                  initiallyExpanded: true,
                  textColor: Colors.deepPurple,
                  iconColor: Colors.deepPurple,
                  title: const Text('Product Infomation',
                      style: TextStyle(fontSize: 18)),
                  children: [
                    ListTile(
                      title: Text(
                        widget.product.productInformation.toString(),
                        style: const TextStyle(fontSize: 14),
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: ExpansionTile(
                  initiallyExpanded: true,
                  textColor: Colors.deepPurple,
                  iconColor: Colors.deepPurple,
                  title: const Text('Delivery Infomation',
                      style: TextStyle(fontSize: 18)),
                  // ignore: prefer_const_literals_to_create_immutables
                  children: [
                    ListTile(
                      title: Text(
                        widget.product.deliveryInformation.toString(),
                        style: const TextStyle(fontSize: 14),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
