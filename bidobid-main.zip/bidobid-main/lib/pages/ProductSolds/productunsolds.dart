import 'package:bidobid/pages/ProductSolds/provider/productsolds.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class ProductUnSoldsScreen extends ConsumerStatefulWidget {
  const ProductUnSoldsScreen({super.key});

  @override
  ConsumerState<ProductUnSoldsScreen> createState() =>
      _ProductUnSoldsScreenState();
}

class _ProductUnSoldsScreenState extends ConsumerState<ProductUnSoldsScreen> {
  @override
  Widget build(BuildContext context) {
    final productsState = ref.watch(productsoldProvider);

    final soldProducts = productsState.where((product) {
      final DateTime soldDate = product.soldDate is String
          ? DateTime.parse(product.soldDate as String)
          : product.soldDate.toDate();

      return product.soldPrice == 0 && soldDate.isBefore(DateTime.now());
    }).toList();

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.deepPurple,
        title: Text(
          'UnSold Products',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: false,
      ),
      body: soldProducts.isEmpty
          ? const Center(
              child: Text(
                "No unsold products available.",
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: soldProducts.length,
              itemBuilder: (context, index) {
                final product = soldProducts[index];

                return Card(
                  elevation: 4,
                  color: Colors.white,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        product.imageUrl,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      product.name,
                      style: GoogleFonts.poppins(
                          fontSize: 18, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Sold for: \$${product.soldPrice}',
                          style: GoogleFonts.poppins(
                              fontSize: 14, color: Colors.grey[700]),
                        ),
                        Text(
                          'Bid Winner: ${product.buyerName ?? 'N/A'}',
                          style: GoogleFonts.poppins(
                              fontSize: 12, color: Colors.grey[500]),
                        ),
                      ],
                    ),
                    trailing: const Icon(Icons.check_circle,
                        color: Colors.green, size: 28),
                  ),
                );
              },
            ),
    );
  }
}
