import 'package:bidobid/pages/ProductSolds/provider/productsolds.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class MyActiveProductScreen extends ConsumerStatefulWidget {
  const MyActiveProductScreen({super.key});

  @override
  ConsumerState<MyActiveProductScreen> createState() =>
      _MyActiveProductScreenState();
}

class _MyActiveProductScreenState extends ConsumerState<MyActiveProductScreen> {
  @override
  Widget build(BuildContext context) {
    final productsState = ref.watch(productsoldProvider);

    final soldProducts = productsState.where((product) {
      final DateTime soldDate = product.soldDate is String
          ? DateTime.parse(product.soldDate as String)
          : product.soldDate.toDate();

      return product.soldPrice >= 0 &&
          soldDate.isAfter(DateTime.now()) &&
          product.approvalStatus == "approved";
    }).toList();

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.deepPurple,
        title: Text(
          'Active Products',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: false,
      ),
      body: soldProducts.isEmpty
          ? const Center(
              child: Text(
                "No active products available.",
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: soldProducts.length,
              itemBuilder: (context, index) {
                final product = soldProducts[index];

                return Card(
                  elevation: 4,
                  color: Colors.white,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          product.imageUrl,
                          width: 80,
                          height: 80,
                          fit: BoxFit.cover,
                        ),
                      ),
                      title: Text(
                        product.name,
                        style: GoogleFonts.poppins(
                            fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Highest Bid: ${product.soldPrice} Pkr',
                            style: GoogleFonts.poppins(
                                fontSize: 14, color: Colors.grey[700]),
                          ),
                          Text(
                            'Base Price: ${product.basePrice ?? 'N/A'} Pkr',
                            style: GoogleFonts.poppins(
                                fontSize: 12, color: Colors.grey[500]),
                          ),
                        ],
                      ),
                      trailing: TextButton(
                        onPressed: () async {
                          await ref
                              .read(productsoldProvider.notifier)
                              .cancelProduct(product.productId, product.name);
                        },
                        style: TextButton.styleFrom(
                            backgroundColor: Colors.deepPurple,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8))),
                        child: Text(
                          "Cancel",
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                          ),
                        ),
                      )),
                );
              },
            ),
    );
  }
}
