// final soldProductsProvider =

import 'dart:developer';

import 'package:bidobid/models/bid_model.dart';
import 'package:bidobid/models/soldproduct_model.dart';
import 'package:bidobid/services/notification_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final productsoldProvider =
    StateNotifierProvider<ProductSoldNotifier, List<SoldProductModel>>(
  (ref) => ProductSoldNotifier(),
);
final notificationService = NotificationServices();

class ProductSoldNotifier extends StateNotifier<List<SoldProductModel>> {
  ProductSoldNotifier() : super([]);

  Future<void> fetchSoldProducts(String userId) async {
    try {
      final productQuery = await FirebaseFirestore.instance
          .collection("products")
          .where("ownerId", isEqualTo: userId)
          .get();
      List<SoldProductModel> soldProducts = [];
      for (var productDoc in productQuery.docs) {
        final bidQuery = await FirebaseFirestore.instance
            .collection("products")
            .doc(productDoc.id)
            .collection("bids")
            .get();

        List<BidModel> bids = bidQuery.docs
            .map(
              (doc) => BidModel.fromSnapshot(doc.data()),
            )
            .toList();
        SoldProductModel product =
            SoldProductModel.fromSnapshot(productDoc, bids);
        soldProducts.add(product);
      }

      state = soldProducts;
    } catch (e) {
      log("Erorr fetching sold products: $e");
    }
  }

  // Future<void> cancelProduct(String productId) async {
  //   try {
  //     final firestore = FirebaseFirestore.instance;

  //     // 1️⃣ Delete all bids from the product's subcollection
  //     final productBidsRef =
  //         firestore.collection("products").doc(productId).collection("bids");
  //     final productBids = await productBidsRef.get();
  //     for (var bid in productBids.docs) {
  //       await bid.reference.delete();
  //     }

  //     // 2️⃣ Find all users who bid on this product and delete the bid from their subcollection
  //     final usersRef = firestore.collection("users");
  //     final users = await usersRef.get();
  //     for (var userDoc in users.docs) {
  //       final userBidsRef =
  //           usersRef.doc(userDoc.id).collection("bids").doc(productId);
  //       final userBidSnapshot = await userBidsRef.get();
  //       if (userBidSnapshot.exists) {
  //         await userBidSnapshot.reference.delete();
  //       }

  //       final userData = userDoc.data();
  //       if (userData.containsKey("deviceToken")) {
  //         String deviceToken = userData["deviceToken"];
  //         await notificationService.sendPushNotification(deviceToken,
  //             "Bid Canceled", "A product you bid on has been canceled.");
  //       }
  //     }

  //     // 3️⃣ Finally, delete the product from the products collection
  //     await firestore.collection("products").doc(productId).delete();

  //     // 4️⃣ Remove the product from local state
  //     state = state.where((product) => product.productId != productId).toList();

  //     log("✅ Product and all related bids deleted successfully.");
  //   } catch (e) {
  //     log("❌ Error deleting product: $e");
  //   }
  // }
  Future<void> cancelProduct(String productId, String productName) async {
    try {
      final firestore = FirebaseFirestore.instance;
      final batch = firestore.batch();

      final productBidsRef =
          firestore.collection("products").doc(productId).collection("bids");
      final productBids = await productBidsRef.get();
      for (var bid in productBids.docs) {
        batch.delete(bid.reference);
      }

      final usersRef = firestore.collection("users");
      final users = await usersRef.get();
      List<Future<void>> notificationFutures = [];

      for (var userDoc in users.docs) {
        final userBidsRef =
            usersRef.doc(userDoc.id).collection("bids").doc(productId);
        final userBidSnapshot = await userBidsRef.get();

        if (userBidSnapshot.exists) {
          batch.delete(userBidSnapshot.reference);
        }

        final userData = userDoc.data();
        if (userData.containsKey("deviceToken")) {
          String deviceToken = userData["deviceToken"];
          notificationFutures.add(notificationService.sendPushNotification(
              deviceToken,
              "Bid Canceled",
              "A product $productName you bid on has been canceled."));
        }
      }

      // 3️⃣ Delete the product from the products collection in the batch
      batch.delete(firestore.collection("products").doc(productId));

      // 4️⃣ Commit the batch operation
      await batch.commit();

      // 5️⃣ Wait for all notifications to be sent (running in parallel)
      await Future.wait(notificationFutures);

      // 6️⃣ Remove the product from local state
      state = state.where((product) => product.productId != productId).toList();

      log("✅ Product and all related bids deleted successfully.");
    } catch (e) {
      log("❌ Error deleting product: $e");
    }
  }
}
