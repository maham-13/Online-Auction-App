import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

final profileImageProvider =
    StateNotifierProvider<ProfileImageNotifier, String?>(
  (ref) {
    return ProfileImageNotifier();
  },
);

class ProfileImageNotifier extends StateNotifier<String?> {
  ProfileImageNotifier() : super(null);

  final ImagePicker picker = ImagePicker();
  final storage = FirebaseStorage.instance;
  final firestore = FirebaseFirestore.instance;

  Future<void> profileImageUpload(ImageSource source, String userId) async {
    final XFile? image = await picker.pickImage(source: source);
    File imageFile = File(image!.path);
    log(image.path);

    final uploadimage =
        await storage.ref('profile_images/profile$userId').putFile(imageFile);
    String downloadUrl = await uploadimage.ref.getDownloadURL();

    await firestore
        .collection('users')
        .doc(userId)
        .update({'userProfile': downloadUrl});
  }
}
