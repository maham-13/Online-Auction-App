import 'dart:developer';
import 'package:bidobid/models/bid_model.dart';
import 'package:bidobid/pages/Bids/provider/bid_provider.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class BidListView extends StatelessWidget {
  final List<BidModel> bids;
  final String title;

  const BidListView({super.key, required this.bids, required this.title});
  String formatBidTime(DateTime dateTime) {
    return DateFormat('dd MMM yyyy, hh:mm a').format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    return bids.isEmpty
        ? Center(child: Text('No $title'))
        : ListView.builder(
            itemCount: bids.length,
            itemBuilder: (context, index) {
              final bid = bids[index];
              return Card(
                color: Colors.white,
                margin: const EdgeInsets.all(8),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Bid ID #${bid.productId.substring(0, 5)}",
                            style: GoogleFonts.outfit(
                                fontSize: 14, fontWeight: FontWeight.w600),
                          ),
                          Text(
                            bid.status.toUpperCase(),
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                color: bid.status == 'win'
                                    ? Colors.green
                                    : bid.status == 'loss'
                                        ? Colors.red
                                        : Colors.orange),
                          )
                        ],
                      ),
                      Text(
                        'Data ${formatBidTime(bid.endTime)}',
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Product ${bid.productName}",
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Bid Amount: Rs. ${bid.bidAmount}",
                            style: GoogleFonts.outfit(
                              fontSize: 16,
                            ),
                          ),
                          bid.status == 'win'
                              ? Deletebutton(
                                  productId: bid.productId,
                                  userId: bid.userId,
                                )
                              : bid.status == 'loss'
                                  ? Deletebutton(
                                      productId: bid.productId,
                                      userId: bid.userId,
                                    )
                                  : TextButton(
                                      onPressed: () async {
                                        log("ontapppppppppppppp");
                                        showDialog(
                                          context: context,
                                          builder: (context) {
                                            return AlertDialog(
                                                backgroundColor: Colors.white,
                                                title: const Icon(
                                                  FontAwesomeIcons
                                                      .circleQuestion,
                                                  size: 80,
                                                  color: Colors.deepPurple,
                                                ),
                                                content: Text(
                                                  'Are you sure you want to cancel this bid?',
                                                  style: GoogleFonts.outfit(
                                                      fontSize: 18,
                                                      fontWeight:
                                                          FontWeight.w600),
                                                ),
                                                actions: [
                                                  TextButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text(
                                                      'No',
                                                      style: GoogleFonts.outfit(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.w600),
                                                    ),
                                                  ),
                                                  TextButton(
                                                    onPressed: () async {
                                                      await bidCancel(
                                                          productId:
                                                              bid.productId,
                                                          userId: bid.userId);
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text(
                                                      "Confirm",
                                                      style: GoogleFonts.outfit(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.w600),
                                                    ),
                                                  )
                                                ]);
                                          },
                                        );
                                      },
                                      style: TextButton.styleFrom(
                                          shape: const RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(12.0))),
                                          backgroundColor: Colors.black,
                                          foregroundColor: Colors.white),
                                      child: const Text(
                                        'Cancel bid',
                                      )),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }
}

class Deletebutton extends StatelessWidget {
  const Deletebutton({
    super.key,
    required this.productId,
    required this.userId,
  });
  final String productId;
  final String userId;
  @override
  Widget build(BuildContext context) {
    return TextButton(
        onPressed: () async {
          log("ontapppppppppppppp");

          await deleteBid(productId: productId, userId: userId);
        },
        style: TextButton.styleFrom(
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0))),
            backgroundColor: Colors.black,
            foregroundColor: Colors.white),
        child: const Text(
          'Delete bid',
        ));
  }
}
