import 'package:bidobid/models/bid_model.dart';
import 'package:bidobid/pages/Bids/bidlist_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BidHistoryScreen extends StatefulWidget {
  const BidHistoryScreen({super.key});

  @override
  State<BidHistoryScreen> createState() => _BidHistoryScreenState();
}

class _BidHistoryScreenState extends State<BidHistoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController tabController;
  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        automaticallyImplyLeading: true,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          'My Bids',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        bottom: TabBar(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          controller: tabController,
          dividerColor: Colors.black,
          indicatorColor: Colors.black,
          indicatorSize: TabBarIndicatorSize.tab,
          indicator: BoxDecoration(
              color: Colors.grey.withOpacity(0.4),
              borderRadius: BorderRadius.circular(4)),
          tabs: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Active',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
              ),
            ),
            Text(
              'Win',
              style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600),
            ),
            Text(
              'Loss',
              style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("users")
            .doc(FirebaseAuth.instance.currentUser?.uid)
            .collection('bids')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No bids found.'));
          }

          final bids = snapshot.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return BidModel.fromSnapshot(data);
          }).toList();

          final pendingBids = bids.where((b) => b.status == 'active').toList();
          final wonBids = bids.where((b) => b.status == 'win').toList();
          final lostBids = bids.where((b) => b.status == 'loss').toList();

          return TabBarView(
            controller: tabController,
            children: [
              BidListView(bids: pendingBids, title: "Active Bids"),
              BidListView(bids: wonBids, title: "Won Bids"),
              BidListView(bids: lostBids, title: "Loss Bids"),
            ],
          );
        },
      ),
    );
  }
}
