import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseFirestore _firestore = FirebaseFirestore.instance;
Future<void> bidCancel(
    {required String productId, required String userId}) async {
  await _firestore
      .collection("products")
      .doc(productId)
      .collection("bids")
      .doc(userId)
      .delete();

  await _firestore
      .collection("users")
      .doc(userId)
      .collection("bids")
      .doc(productId)
      .delete();

  QuerySnapshot remainingbidSnapshot = await _firestore
      .collection("products")
      .doc(productId)
      .collection("bids")
      .orderBy("bidAmount", descending: true)
      .get();
  log(remainingbidSnapshot.docs.toString());
  int highestBidAmount = 0;
  String highestBidderId = "";
// !!!!!!!!!!!!!!!!!!!!!!!!!!
  if (remainingbidSnapshot.docs.isNotEmpty) {
    log(remainingbidSnapshot.docs.length.toString());
    var highestBidData =
        remainingbidSnapshot.docs.first.data() as Map<String, dynamic>;
    highestBidAmount = highestBidData["bidAmount"] ?? 0;
    highestBidderId = highestBidData["userId"] ?? "";
    log("hiestbidAmount $highestBidAmount and highestBidderId $highestBidderId");
    await _firestore.collection("products").doc(productId).update({
      "highestbidamount": highestBidAmount,
      "highestbidid": highestBidderId,
    });
  } else {
    await _firestore.collection("products").doc(productId).update({
      "highestbidamount": highestBidAmount,
      "highestbidid": highestBidderId,
    });
  }

  log("successfull operated");
}

Future<void> deleteBid(
    {required String userId, required String productId}) async {
  await _firestore
      .collection("users")
      .doc(userId)
      .collection("bids")
      .doc(productId)
      .delete();
}
