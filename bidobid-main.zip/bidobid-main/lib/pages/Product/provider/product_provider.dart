import 'dart:io';

import 'package:bidobid/models/product_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

final addproductProvider = StateNotifierProvider<ProductNotifier, Product?>(
    (ref) => ProductNotifier());

class ProductNotifier extends StateNotifier<Product?> {
  ProductNotifier() : super(null);

  Future<void> launchProduct(
      {required Product productItem, required XFile image}) async {
    try {
      final productDocRef =
          FirebaseFirestore.instance.collection('products').doc();
      final productId = productDocRef.id;
      final storageRef =
          FirebaseStorage.instance.ref().child('product_images/$productId');
      await storageRef.putFile(File(image!.path));

      String imageUrl = await storageRef.getDownloadURL();

      Product updateProduct =
          productItem.copyWith(imageUrl: imageUrl, productid: productId);
      await productDocRef.set(updateProduct.toProductMap());
    } catch (e) {
      throw Exception("Failed to upload product");
    }
  }
}
