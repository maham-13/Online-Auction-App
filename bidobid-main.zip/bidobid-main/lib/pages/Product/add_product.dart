// ignore_for_file: file_names, use_build_context_synchronously, non_constant_identifier_names

import 'dart:developer';
import 'dart:io';

import 'package:bidobid/models/product_model.dart';
import 'package:bidobid/models/user_model.dart';
import 'package:bidobid/pages/Authentication/provider/auth_provider.dart';
import 'package:bidobid/pages/Product/provider/product_provider.dart';
import 'package:bidobid/widget/textfield_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../../widget/widget.dart';

class UserAddProduct extends ConsumerStatefulWidget {
  const UserAddProduct({super.key});
  @override
  ConsumerState<UserAddProduct> createState() => _UserAddProductState();
}

class _UserAddProductState extends ConsumerState<UserAddProduct> {
  late TextEditingController _productNameController;
  late TextEditingController _categoryController;
  late TextEditingController _imageUrlController;
  late TextEditingController _priceController;
  late TextEditingController _endDateController;
  late TextEditingController _productInformationController;
  late TextEditingController _deliveryInformationController;
  bool textFieldEmpty = false;
  // String? _imageUrl;
  XFile? image;
  // UserModel? modal;

  // @override
  // void initState() {
  //   super.initState();
  // }
  void clearTextField() {
    _productNameController.text = "";
    _categoryController.text = "";
    _imageUrlController.text = "";
    _priceController.text = "";
    _endDateController.text = "";
    _productInformationController.text = "";
    _deliveryInformationController.text = "";
  }

  @override
  void initState() {
    super.initState();
    _productNameController = TextEditingController();
    _categoryController = TextEditingController();
    _imageUrlController = TextEditingController();
    _priceController = TextEditingController();
    _endDateController = TextEditingController();
    _productInformationController = TextEditingController();
    _deliveryInformationController = TextEditingController();
  }

  @override
  void dispose() {
    _productNameController.dispose();
    _categoryController.dispose();
    _imageUrlController.dispose();
    _priceController.dispose();
    _endDateController.dispose();
    _productInformationController.dispose();
    _deliveryInformationController.dispose();
    super.dispose();
  }

  Future<void> _uploadGallery() async {
    final ImagePicker picker = ImagePicker();
    image = await picker.pickImage(source: ImageSource.gallery);
  }

  Future<void> _uploadCamera() async {
    final ImagePicker picker = ImagePicker();
    image = await picker.pickImage(source: ImageSource.camera);
  }

  @override
  Widget build(BuildContext context) {
    final userinfo = ref.read(authProvider);
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Text(
          'ADD PRODUCT',
          style: GoogleFonts.bebasNeue(
            fontSize: 30,
            color: Colors.white,
          ),
        ),
        elevation: 0,
        centerTitle: false,
        automaticallyImplyLeading: false,
      ),
      body: Container(
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(15),
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 20),
                const SectionTitle(title: 'FILL TO LAUNCH'),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      color: Colors.grey[200],
                      border: Border.all(color: Colors.white),
                    ),
                    child: Column(
                      children: [
                        const SizedBox(height: 10),
                        const Text(
                          'Upload Product Image',
                          style: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                              onPressed: () async {
                                await _uploadGallery();
                                log("data is uplaod");
                              },
                              icon: const Icon(
                                Icons.photo_album_outlined,
                              ),
                            ),
                            IconButton(
                              onPressed: () async {
                                await _uploadCamera();
                                log("data is uplaod");
                              },
                              icon: const Icon(
                                Icons.camera_alt_outlined,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Custom_textfield(
                    hinttext: "Product Name",
                    controller: _productNameController,
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Custom_textfield(
                    hinttext: "Select Product Category",
                    controller: _categoryController,
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Custom_textfield(
                    hinttext: "Starting Bid",
                    controller: _priceController,
                    type: TextInputType.number,
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: TextField(
                    controller: _endDateController,
                    enableSuggestions: true,
                    readOnly: true,
                    decoration: InputDecoration(
                      suffixIcon: Icon(
                        Icons.calendar_today_outlined,
                        color: Colors.grey[200],
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      hintText: 'End of Session',
                      fillColor: Colors.grey[200],
                      filled: true,
                    ),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2101));

                      if (pickedDate != null) {
                        String formattedDate =
                            DateFormat('yyyy-MM-dd').format(pickedDate);
                        setState(() {
                          _endDateController.text =
                              formattedDate; //set output date to TextField value.
                        });
                      } else {
                        const snackBar =
                            SnackBar(content: Text('Date not added'));
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      }
                    },
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Custom_textfield(
                    hinttext: "Product Details",
                    controller: _productInformationController,
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Custom_textfield(
                    hinttext: "Delivery Details",
                    controller: _deliveryInformationController,
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: GestureDetector(
                    onTap: () async {
                      if (_productNameController.text.isEmpty ||
                          _priceController.text.isEmpty ||
                          _endDateController.text.isEmpty ||
                          image == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Please fill all fields')));
                        return;
                      }

                      try {
                        final product = Product(
                          productid: "",
                          name: _productNameController.text,
                          category: _categoryController.text,
                          imageUrl: '',
                          baseprice: int.parse(_priceController.text.trim()),
                          isRecommended: false,
                          isPopular: false,
                          ownerEmail: userinfo!.email,
                          ownerName: userinfo.name,
                          ownerId: userinfo.uid,
                          ownerProfile: userinfo.userprofile,
                          endDate: Timestamp.fromDate(
                              DateTime.parse(_endDateController.text)),
                          productInformation:
                              _productInformationController.text,
                          deliveryInformation:
                              _deliveryInformationController.text,
                          approvalStatus: 'pending',
                          highestbidamount: 0,
                          highestbidid: '',
                          status: 'active',
                          bidwinnerName: '',
                        );
                        ref
                            .read(addproductProvider.notifier)
                            .launchProduct(productItem: product, image: image!);
                        clearTextField();
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content:
                                    Text('Product submitted for approval')));
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Error: ${e.toString()}')),
                        );
                      }
                      // await _uploadImage();
                      // await _launchProduct();
                    },
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                          color: Colors.deepPurple,
                          borderRadius: BorderRadius.circular(12)),
                      child: const Center(
                        child: Text(
                          'Launch Product',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 17),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
