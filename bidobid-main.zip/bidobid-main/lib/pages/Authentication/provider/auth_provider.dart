import 'dart:developer';
import 'package:bidobid/models/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final authProvider = StateNotifierProvider<AuthNotifier, UserModel?>(
  (ref) => AuthNotifier(),
);
final apikeyprovider = StateProvider<String>((ref) => '');

class AuthNotifier extends StateNotifier<UserModel?> {
  AuthNotifier() : super(null);
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firstore = FirebaseFirestore.instance;

  Future<void> signUpWithEmail(String email, String password, String name,
      String phoneNumber, String role, Map<String, dynamic> location) async {
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;

      if (user != null) {
        if (!user.emailVerified) {
          await user.sendEmailVerification();
        }
        String? deviceToken = await FirebaseMessaging.instance.getToken();
        UserModel newUser = UserModel(
          uid: user.uid,
          email: user.email!,
          name: name,
          phone: phoneNumber,
          location: location,
          role: role,
          deviceToken: deviceToken ?? "",
          userprofile: "",
          deliveryInfo: {},
          createdAt: DateTime.now().toString(),
        );

        await _firstore.collection("users").doc(user.uid).set(newUser.toMap());
        state = newUser;
      }
    } catch (e) {
      throw Exception("Sign-up failed: $e");
    }
  }

  Future<void> login(String email, String password, WidgetRef ref) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;

      if (user != null) {
        await user.reload();
        if (!user.emailVerified) {
          log("Exception error ");
          throw Exception("Email not verified. Please check your inbox.");
        }
        DocumentSnapshot snapshot =
            await _firstore.collection('users').doc(user.uid).get();

        UserModel userModel =
            UserModel.fromMap(snapshot.data() as Map<String, dynamic>);
        String? newDeviceToken = await FirebaseMessaging.instance.getToken();

        if (newDeviceToken != null && newDeviceToken != userModel.deviceToken) {
          log("FCM Token changed, updating Firestore...");

          userModel = userModel.copyWith(deviceToken: newDeviceToken);
          await _firstore
              .collection("users")
              .doc(user.uid)
              .set(userModel.toMap());
        }
        final apikeysnapshot = await FirebaseFirestore.instance
            .collection('apikey')
            .limit(1)
            .get();

        // if (apikeysnapshot.docs.isEmpty) {
        //   log("No API key found in Firestore!");
        //   return;
        // }

        final apiKey = apikeysnapshot.docs.first.data()['key'] as String;
        log("Fetched API Key: $apiKey");
        ref.read(apikeyprovider.notifier).state = apiKey;
        state = userModel;
      }
    } on FirebaseAuthException catch (e) {
      throw Exception("Login failed: ${e.message}");
    }
  }

  Future<bool> checkEmailVerification() async {
    User? user = _auth.currentUser;
    await user?.reload();
    return user?.emailVerified ?? false;
  }

  Future<void> resendEmailVerification() async {
    User? user = _auth.currentUser;
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
    }
  }

  // Future<void> saveUserData(UserModel user) async {
  //   await _firstore.collection("users").doc(user.uid).set(user.toMap());
  //   state = user;
  // }
  Future<void> getuserProfile(String userId) async {
    final userSnap = await _firstore.collection("users").doc(userId).get().then(
      (value) {
        return UserModel.fromMap(value.data() as Map<String, dynamic>);
      },
    );
    state = userSnap;
  }
}
