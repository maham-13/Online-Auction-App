import 'package:bidobid/auth/navigation.dart';
import 'package:bidobid/models/bid_model.dart';
import 'package:bidobid/models/cart_model.dart';
import 'package:bidobid/pages/Authentication/provider/auth_provider.dart';
import 'package:bidobid/pages/Cart/provider/cart_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class UserCart extends ConsumerStatefulWidget {
  const UserCart({super.key});

  @override
  ConsumerState<UserCart> createState() => _UserCartState();
}

class _UserCartState extends ConsumerState<UserCart> {
  late TextEditingController bidamountController;
  @override
  void initState() {
    super.initState();
    bidamountController = TextEditingController();
  }

  @override
  void dispose() {
    bidamountController.dispose();
    super.dispose();
  }

  double cartItemSubtotal(List<CartModel> cartItem) {
    double subtotal = 0.0;
    for (var item in cartItem) {
      if (item.bidprice <= 0) {
        subtotal += item.baseprice;
      } else {
        subtotal += item.bidprice;
      }
    }
    return subtotal;
  }

  int delivery = 150;
  double cartitemTotal(List<CartModel> cartItem) {
    double total = 0.0;
    for (var item in cartItem) {
      if (item.bidprice <= 0) {
        total += item.baseprice;
      } else {
        total += item.bidprice;
      }
    }

    if (total > 1000) {
      return total;
    } else {
      return total + delivery;
    }
  }

  @override
  Widget build(BuildContext context) {
    final widthScreen = MediaQuery.of(context).size.width;
    final cartlist = ref.watch(cartprovider);
    final currentUser = ref.watch(authProvider);
    ref.read(cartprovider.notifier).fetchCartItems(currentUser!.uid);
    // ref.read(cartprovider.notifier).checkBidPriceChanges(currentUser.uid);

    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.deepPurple,
        title: Text(
          'CART',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        elevation: 0,
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.black.withOpacity(0.04),
        height: 120,
        child: Column(
          children: [
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'SUBTOTAL',
                      style: GoogleFonts.outfit(fontSize: 12),
                    ),
                    Text('Rs ${cartItemSubtotal(cartlist).ceil()}',
                        style: GoogleFonts.outfit(fontSize: 12)),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'DELIVERY FEE',
                      style: GoogleFonts.outfit(fontSize: 12),
                    ),
                    Text('Rs ${cartitemTotal(cartlist) > 1000 ? 0 : 150}',
                        style: GoogleFonts.outfit(fontSize: 12)),
                  ],
                ),
              ],
            ),
            Stack(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 50,
                  alignment: Alignment.bottomCenter,
                  color: Colors.black.withAlpha(50),
                ),
                Container(
                  margin: const EdgeInsets.all(5),
                  width: MediaQuery.of(context).size.width - 10,
                  height: 40,
                  color: Colors.deepPurple.withAlpha(180),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'TOTAL',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                        Text(
                          'Rs ${cartitemTotal(cartlist).ceil()}',
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Free Delivery',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return const Navbar();
                              },
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepPurple,
                            foregroundColor: Colors.white),
                        child: const Text('Add More Items'),
                      ),
                    ],
                  ),
                  ListView.builder(
                    itemCount: cartlist.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      final cartItem = cartlist[index];
                      return Dismissible(
                        key: Key(cartItem.productid),
                        background: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12.0),
                              color: Colors.deepPurple,
                            ),
                            alignment: Alignment.centerLeft,
                            padding:
                                const EdgeInsets.symmetric(horizontal: 20.0),
                            child:
                                const Icon(Icons.delete, color: Colors.white),
                          ),
                        ),
                        direction: DismissDirection.startToEnd,
                        onDismissed: (direction) {
                          ref.read(cartprovider.notifier).removeFromCart(
                              cartItem.productid, currentUser.uid);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content:
                                  Text("${cartItem.name} removed from cart")));
                        },
                        child: SizedBox(
                          width: double.infinity,
                          child: Card(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            color: Colors.white,
                            elevation: 3,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                ClipRRect(
                                  borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(12),
                                    topLeft: Radius.circular(12),
                                  ),
                                  child: CachedNetworkImage(
                                    imageUrl: cartItem.image,
                                    fit: BoxFit.fill,
                                    width: 110,
                                    height: 100,
                                    fadeInCurve: Curves.bounceInOut,
                                    placeholder: (context, url) => Container(
                                      color: Colors.black.withOpacity(0.04),
                                      // radius: 150,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        cartItem.name,
                                        style: GoogleFonts.nunito(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w700),
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            cartItem.baseprice
                                                .ceil()
                                                .toString(),
                                            style: GoogleFonts.nunito(
                                                fontSize: 14,
                                                color: Colors.grey,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 8.0),
                                            child: Text(
                                              'Rs. ${cartItem.bidprice.ceil()} Bid',
                                              style: GoogleFonts.nunito(
                                                  color: Colors.green,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                        ],
                                      ),
                                      InkWell(
                                        onTap: () {
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                backgroundColor: Colors.white,
                                                contentPadding:
                                                    const EdgeInsets.all(20),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                                title: Column(
                                                  children: [
                                                    const Icon(
                                                      Icons
                                                          .check_circle_rounded,
                                                      size: 80,
                                                      color: Colors.deepPurple,
                                                    ),
                                                    const SizedBox(height: 10),
                                                    Text('Place Bid',
                                                        style:
                                                            GoogleFonts.outfit(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                fontSize:
                                                                    widthScreen *
                                                                        0.08)),
                                                    const SizedBox(height: 5),
                                                    Text(
                                                      'Please confirm your bid amount below.',
                                                      style: GoogleFonts.outfit(
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontSize:
                                                              widthScreen *
                                                                  0.04),
                                                      textAlign:
                                                          TextAlign.center,
                                                    ),
                                                  ],
                                                ),
                                                content: TextFormField(
                                                  controller:
                                                      bidamountController,
                                                  // validator: (value) {

                                                  // },
                                                  decoration: InputDecoration(
                                                    labelText:
                                                        'Enter your bid amount',
                                                    labelStyle:
                                                        GoogleFonts.outfit(),
                                                    border:
                                                        const OutlineInputBorder(),
                                                  ),
                                                  keyboardType:
                                                      TextInputType.number,
                                                ),
                                                actions: [
                                                  TextButton(
                                                    onPressed: () {
                                                      if (bidamountController
                                                          .text.isNotEmpty) {
                                                        final amount =
                                                            int.tryParse(
                                                                bidamountController
                                                                    .text);
                                                        if (amount! <=
                                                                cartItem.bidprice +
                                                                    99 ||
                                                            amount <=
                                                                cartItem.baseprice +
                                                                    99) {
                                                          Navigator.of(context)
                                                              .pop();
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                                  const SnackBar(
                                                                      content: Text(
                                                                          "Please Enter Amount greater then 100 Rs of Product bid amount ")));
                                                        } else if (amount >=
                                                                cartItem.baseprice +
                                                                    99 &&
                                                            amount >=
                                                                cartItem.baseprice +
                                                                    99) {
                                                          final bidItem = BidModel(
                                                              userId: currentUser
                                                                  .uid,
                                                              userName:
                                                                  currentUser
                                                                      .name,
                                                              userProfile:
                                                                  currentUser
                                                                      .userprofile,
                                                              userFcmToken:
                                                                  currentUser
                                                                      .deviceToken,
                                                              productId: cartItem
                                                                  .productid,
                                                              productName:
                                                                  cartItem.name,
                                                              bidAmount: amount,
                                                              endTime: cartItem
                                                                  .endtime
                                                                  .toDate(),
                                                              status: "active");
                                                          ref
                                                              .read(cartprovider
                                                                  .notifier)
                                                              .placebidandremoveCart(
                                                                  bidItem:
                                                                      bidItem);
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                                  const SnackBar(
                                                                      content: Text(
                                                                          "Bid Placed Successfully")));
                                                          Navigator.of(context)
                                                              .pop();
                                                        }
                                                      } else {
                                                        Navigator.of(context)
                                                            .pop();
                                                        ScaffoldMessenger.of(
                                                                context)
                                                            .showSnackBar(
                                                                const SnackBar(
                                                                    content: Text(
                                                                        "Please Enter Amount.")));
                                                      }
                                                    },
                                                    style: TextButton.styleFrom(
                                                        minimumSize: const Size(
                                                            double.infinity,
                                                            56),
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        12.0)),
                                                        backgroundColor:
                                                            Colors.deepPurple,
                                                        foregroundColor:
                                                            Colors.white),
                                                    child: Text(
                                                      'Confirm',
                                                      style: GoogleFonts.outfit(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w600),
                                                    ),
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        },
                                        child: Align(
                                          alignment: Alignment.centerRight,
                                          child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(12.0),
                                                color: Colors.black,
                                              ),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Text(
                                                  "Bid Now",
                                                  style: GoogleFonts.outfit(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
