import 'dart:developer';

import 'package:bidobid/models/bid_model.dart';
import 'package:bidobid/models/cart_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final cartprovider =
    StateNotifierProvider<CartNotifier, List<CartModel>>((ref) {
  return CartNotifier();
});

class CartNotifier extends StateNotifier<List<CartModel>> {
  CartNotifier() : super([]);
  final _firestore = FirebaseFirestore.instance;

  Future<void> fetchCartItems(String userId) async {
    final cartsnapshot = await _firestore
        .collection("users")
        .doc(userId)
        .collection("cart")
        .get();

    state = cartsnapshot.docs
        .map(
          (doc) => CartModel.fromSnapShot(doc),
        )
        .toList();
  }

  Future<void> addToCart(
      {required CartModel cartItem, required String userId}) async {
    final cartRef = _firestore
        .collection("users")
        .doc(userId)
        .collection("cart")
        .doc(cartItem.productid);

    await cartRef.set(cartItem.toMap());
    state = [
      ...state.where((item) => item.productid != cartItem.productid),
      cartItem
    ];
  }

  void removeFromCart(String productid, String userId) async {
    await _firestore
        .collection("users")
        .doc(userId)
        .collection("cart")
        .doc(productid)
        .delete();

    state = state
        .where(
          (item) => item.productid != productid,
        )
        .toList();
  }

  Future<void> checkBidPriceChanges(String userId) async {
    _firestore
        .collection("users")
        .doc(userId)
        .collection("cart")
        .snapshots()
        .listen(
      (cartSnapshot) {
        for (var cartDoc in cartSnapshot.docs) {
          String productId = cartDoc.id;

          _firestore.collection("products").doc(productId).snapshots().listen(
            (productDoc) {
              if (productDoc.exists) {
                int latestbidPrice =
                    productDoc.data()?["highestbidamount"] ?? 0;

                if (cartDoc.data()["bidprice"] != latestbidPrice) {
                  _firestore
                      .collection("users")
                      .doc(userId)
                      .collection("cart")
                      .doc(productId)
                      .update({"bidprice": latestbidPrice});
                  state = state.map(
                    (item) {
                      if (item.productid == productId) {
                        return CartModel(
                            productid: item.productid,
                            name: item.name,
                            image: item.image,
                            endtime: item.endtime,
                            baseprice: item.baseprice,
                            bidprice: item.bidprice);
                      }
                      return item;
                    },
                  ).toList();
                }
              }
            },
          );
        }
      },
    );
  }

  Future<void> placebidandremoveCart({required BidModel bidItem}) async {
    await _firestore
        .collection("users")
        .doc(bidItem.userId)
        .collection("cart")
        .doc(bidItem.productId)
        .delete();
    await _firestore
        .collection("products")
        .doc(bidItem.productId)
        .collection("bids")
        .doc(bidItem.userId)
        .set(bidItem.toBidMap());
    await _firestore
        .collection("users")
        .doc(bidItem.userId)
        .collection("bids")
        .doc(bidItem.productId)
        .set(bidItem.toBidMap());
    await _firestore.collection("products").doc(bidItem.productId).update({
      "highestbidamount": bidItem.bidAmount,
      "highestbidid": bidItem.userId,
    });
    log("success");
  }
}
