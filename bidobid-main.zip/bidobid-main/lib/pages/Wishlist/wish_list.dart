import 'package:bidobid/models/cart_model.dart';
import 'package:bidobid/pages/Authentication/provider/auth_provider.dart';
import 'package:bidobid/pages/Cart/provider/cart_provider.dart';
import 'package:bidobid/pages/Wishlist/provider/wishlist_provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class WishlistPage extends ConsumerStatefulWidget {
  const WishlistPage({super.key});

  @override
  ConsumerState<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends ConsumerState<WishlistPage> {
  @override
  Widget build(BuildContext context) {
    final wishlist = ref.watch(wishlistprovider);
    final currentUser = ref.watch(authProvider);
    ref.read(wishlistprovider.notifier).fetchWishlistItems(currentUser!.uid);
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        title: Text(
          'WISHLIST',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: false,
      ),
      body: SafeArea(
          child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(15),
                  topRight: Radius.circular(15),
                ),
              ),
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 16,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 1.0,
                ),
                itemCount: wishlist.length,
                itemBuilder: (BuildContext context, int index) {
                  final product = wishlist[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4.0),
                    child: Container(
                      width: 150, // Set a fixed width for each item
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Stack(children: [
                            SizedBox(
                              height: 100, // Define a fixed height
                              width: double.infinity,
                              child: ClipRRect(
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(8.0),
                                  topRight: Radius.circular(8.0),
                                ),
                                child: CachedNetworkImage(
                                  imageUrl: product.image,
                                  // width: 150,
                                  fit: BoxFit.fill,
                                  placeholder: (context, url) => Container(
                                    color: Colors.black.withOpacity(0.04),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              top: 0,
                              right: 0,
                              child: IconButton(
                                icon: const Icon(
                                  Icons.favorite_outlined,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  ref
                                      .read(wishlistprovider.notifier)
                                      .removeFromWishlist(
                                          product.productid, currentUser.uid);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            "${product.name} removed from wishlist")),
                                  );
                                },
                              ),
                            ),
                          ]),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              product.name,
                              style: GoogleFonts.nunito(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Rs. ${product.baseprice.ceil().toString()}",
                                      style: GoogleFonts.nunito(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  final cartItem = CartModel(
                                      productid: product.productid,
                                      name: product.name,
                                      image: product.image,
                                      endtime: product.endtime,
                                      baseprice: product.baseprice,
                                      bidprice: product.bidprice);
                                  ref.read(cartprovider.notifier).addToCart(
                                      cartItem: cartItem,
                                      userId: currentUser.uid);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: CircleAvatar(
                                    backgroundColor:
                                        Colors.black.withOpacity(0.8),
                                    radius: 18,
                                    child: const Icon(
                                      Icons.shopping_cart_outlined,
                                      size: 20,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4.0),
                        ],
                      ),
                    ),
                  );
                },
              ))),
    );
  }
}
