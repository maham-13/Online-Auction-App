import 'package:bidobid/models/wishlist_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final wishlistprovider =
    StateNotifierProvider<WishlistNotifier, List<WishlistModel>>((ref) {
  return WishlistNotifier();
});

class WishlistNotifier extends StateNotifier<List<WishlistModel>> {
  WishlistNotifier() : super([]);
  final _firestore = FirebaseFirestore.instance;

  Future<void> fetchWishlistItems(String userId) async {
    final cartsnapshot = await _firestore
        .collection("users")
        .doc(userId)
        .collection("wishlist")
        .get();

    state = cartsnapshot.docs
        .map(
          (doc) => WishlistModel.fromSnapShot(doc),
        )
        .toList();
  }

  Future<void> addToWislist(
      {required WishlistModel wishlistitem, required String userId}) async {
    await _firestore
        .collection("users")
        .doc(userId)
        .collection("wishlist")
        .doc(wishlistitem.productid)
        .set(wishlistitem.toMap());
    state = [
      ...state.where(
        (element) => element.productid != wishlistitem.productid,
      )
    ];
  }

  Future<void> removeFromWishlist(String productid, String userId) async {
    await _firestore
        .collection("users")
        .doc(userId)
        .collection("wishlist")
        .doc(productid)
        .delete();

    state = state
        .where(
          (item) => item.productid != productid,
        )
        .toList();
  }
}
