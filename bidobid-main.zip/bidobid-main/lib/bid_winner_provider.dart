import 'dart:developer';
import 'package:bidobid/services/notification_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final bidWinnerProvider = Provider<BidWinnerNotifier>((ref) {
  return BidWinnerNotifier();
});

class BidWinnerNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final NotificationServices notificationServices = NotificationServices();

  Future<void> checkAndAnnounceWinners() async {
    final now = Timestamp.now();

    final approvedProducts = await _firestore
        .collection("products")
        .where("status", isEqualTo: "active")
        .get();

    final expiredBidsSnapshot = approvedProducts.docs
        .where((doc) => doc["endDate"].toDate().isBefore(DateTime.now()))
        .toList();

    for (var productDoc in expiredBidsSnapshot) {
      String productId = productDoc.id;

      // 🔹 Fetch **ALL** bids, not just the highest one
      final bidsSnapshot = await _firestore
          .collection("products")
          .doc(productId)
          .collection("bids")
          .orderBy("bidAmount", descending: true)
          .get(); // ❌ Removed .limit(1)

      if (bidsSnapshot.docs.isNotEmpty) {
        var highestBid = bidsSnapshot.docs.first;
        String winnerUserId = highestBid["userId"];
        int winningAmount = highestBid["bidAmount"];
        String bidwinnerName = highestBid["userName"];

        /// ✅ Update the product with the winner details
        await _firestore.collection("products").doc(productId).update({
          "highestbidamount": winningAmount,
          "highestbidid": winnerUserId,
          "status": "completed",
          "bidwinnerName": bidwinnerName,
        });
        await _firestore
            .collection("products")
            .doc(productId)
            .collection("bids")
            .doc(winnerUserId)
            .set({"status": "win"}, SetOptions(merge: true));

        /// ✅ Save the winning bid in the user's bid history
        await _firestore
            .collection("users")
            .doc(winnerUserId)
            .collection("bids")
            .doc(productId)
            .set({
          "productId": productId,
          "bidAmount": winningAmount,
          "status": "win",
          "timeStamp": now,
        }, SetOptions(merge: true));

        /// ✅ Update all other users' bids as "lost"
        for (var bid in bidsSnapshot.docs) {
          String userId = bid["userId"];
          if (userId != winnerUserId) {
            log("Updating bid for user $userId - bidId: ${bid.id}");

            //? 🔹 Update status in product's bids collection
            await _firestore
                .collection("products")
                .doc(productId)
                .collection("bids")
                .doc(bid.id)
                .set({"status": "loss"}, SetOptions(merge: true));

            //! 🔹 Update status in user's bid history
            await _firestore
                .collection("users")
                .doc(userId)
                .collection("bids")
                .doc(productId)
                .set({"status": "loss"}, SetOptions(merge: true));
          }
        }

        /// ✅ Send Notification to the Winner
        DocumentSnapshot userDoc =
            await _firestore.collection("users").doc(winnerUserId).get();

        String? receiveToken = userDoc["deviceToken"];
        String? userName = userDoc["name"];
        if (receiveToken != null) {
          await notificationServices.sendPushNotification(receiveToken,
              userName ?? "Dear Buyer", "🎉✨🎁You won the auction");
        }
        log("🏆 Winner Announced: $winnerUserId for product $productId");
      } else {
        /// If no bids were placed, just mark the product as completed
        await _firestore.collection("products").doc(productId).update({
          "status": "completed",
        });

        log("❌ No bids placed for product $productId");
      }
    }
  }
}
