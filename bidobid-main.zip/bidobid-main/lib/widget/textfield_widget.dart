import 'package:flutter/material.dart';

class Custom_textfield extends StatelessWidget {
  const Custom_textfield({
    super.key,
    required this.controller,
    required this.hinttext,
    this.type,
  });
  final TextInputType? type;

  final String hinttext;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      enableSuggestions: true,
      keyboardType: type ?? TextInputType.text,
      decoration: InputDecoration(
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.white),
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.deepPurple),
          borderRadius: BorderRadius.circular(10),
        ),
        hintText: hinttext,
        fillColor: Colors.grey[200],
        filled: true,
      ),
    );
  }
}
