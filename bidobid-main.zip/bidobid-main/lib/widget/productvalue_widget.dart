import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Productvaluewidget extends StatelessWidget {
  const Productvaluewidget({
    super.key,
    required this.value,
    this.height,
  });

  final String value;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.all(4.0),
      width: double.infinity,
      height: height,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.04),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.deepPurple, width: 2),
      ),
      child: Text(
        value,
        style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.w400),
      ),
    );
  }
}
