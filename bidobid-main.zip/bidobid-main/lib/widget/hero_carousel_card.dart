// ignore_for_file: prefer_const_constructors, unnecessary_this

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../models/product_model.dart';

class HeroCarouselCard extends StatelessWidget {
  const HeroCarouselCard({super.key, this.product});

  final Product? product;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: 5.0,
        vertical: 20,
      ),
      child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(5.0)),
          child: CachedNetworkImage(
            imageUrl: product!.imageUrl.toString(),
            fit: BoxFit.fill,
            width: double.infinity,
            placeholder: (context, url) {
              return Container(
                color: Colors.black.withOpacity(0.04),
                width: double.infinity,
              );
            },
          )),
    );
  }
}
