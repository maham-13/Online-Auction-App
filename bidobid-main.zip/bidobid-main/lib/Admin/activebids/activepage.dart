import 'package:bidobid/models/product_model.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class ActiveBidListView extends StatelessWidget {
  final List<Product> bids;
  final String title;

  const ActiveBidListView({super.key, required this.bids, required this.title});
  String formatBidTime(DateTime dateTime) {
    return DateFormat('dd MMM yyyy, hh:mm a').format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    return bids.isEmpty
        ? Center(child: Text('No $title'))
        : ListView.builder(
            itemCount: bids.length,
            itemBuilder: (context, index) {
              final bid = bids[index];
              return Card(
                color: Colors.white,
                margin: const EdgeInsets.all(8),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ListTile(
                        leading: CachedNetworkImage(
                          imageUrl: bid.imageUrl,
                          width: 50,
                        ),
                        title: Text(
                          bid.name,
                          style: GoogleFonts.outfit(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(bid.category),
                        trailing: Text(
                          bid.status.toUpperCase(),
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              color: bid.status == 'win'
                                  ? Colors.green
                                  : bid.status == 'loss'
                                      ? Colors.red
                                      : Colors.orange),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Bid ID #${bid.productid.substring(0, 5)}",
                            style: GoogleFonts.outfit(
                                fontSize: 14, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      Text(
                        'Date ${formatBidTime(bid.endDate.toDate())}',
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Product ${bid.productInformation}",
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        "Bid Amount: Rs. ${bid.highestbidamount}",
                        style: GoogleFonts.outfit(
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        'Delivery Information: ${bid.deliveryInformation}',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Text(
                        'Seller Email: ${bid.ownerEmail}',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Text(
                        'Seller Name: ${bid.ownerName}',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }
}
