import 'package:bidobid/models/product_model.dart';
import 'package:bidobid/Admin/activebids/activepage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ActiveBidPage extends StatefulWidget {
  const ActiveBidPage({super.key});

  @override
  State<ActiveBidPage> createState() => _ActiveBidScreenState();
}

class _ActiveBidScreenState extends State<ActiveBidPage>
    with SingleTickerProviderStateMixin {
  late TabController tabController;
  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        automaticallyImplyLeading: true,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          'My Bids',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        bottom: TabBar(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          controller: tabController,
          dividerColor: Colors.black,
          indicatorColor: Colors.black,
          indicatorSize: TabBarIndicatorSize.tab,
          indicator: BoxDecoration(
              color: Colors.grey.withOpacity(0.4),
              borderRadius: BorderRadius.circular(4)),
          tabs: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Active',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
              ),
            ),
            Text(
              'Completed',
              style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("products").snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No bids found.'));
          }

          final bids = snapshot.data!.docs.map((doc) {
            // final data = doc.data() as Map<String, dynamic>;
            return Product.fromSnapshot(doc);
          }).toList();

          final pendingBids = bids.where((b) => b.status == 'active').toList();
          final completedBids =
              bids.where((b) => b.status == 'completed').toList();

          return TabBarView(
            controller: tabController,
            children: [
              ActiveBidListView(bids: pendingBids, title: "Active Bids"),
              ActiveBidListView(bids: completedBids, title: "Completed Bids"),
            ],
          );
        },
      ),
    );
  }
}
