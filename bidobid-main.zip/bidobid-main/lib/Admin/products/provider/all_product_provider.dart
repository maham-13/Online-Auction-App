import 'package:bidobid/models/product_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// ! sabhi product fiebase se fetch ho rhi hain and map kia hai product modal class constrcutor k sath.
final productProvider = StreamProvider<List<Product>>(
  (ref) {
    return FirebaseFirestore.instance
        .collection("products")
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => Product.fromSnapshot(doc)).toList();
    });
  },
);

final productdetailsProvider =
    StateNotifierProvider<ProductNotifier, Product?>((ref) {
  return ProductNotifier();
});

class ProductNotifier extends StateNotifier<Product?> {
  ProductNotifier() : super(null);

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void setProduct(Product product) {
    state = product;
  }

  Future<void> updateProduct(
      String productId, Map<String, dynamic> updatedData) async {
    await _firestore.collection('products').doc(productId).update(updatedData);
    if (state != null) {
      state = state!.copyWith(
        name: updatedData['name'] ?? state!.name,
        baseprice: updatedData['baseprice'] ?? state!.baseprice,
        category: updatedData['category'] ?? state!.category,
        productInformation:
            updatedData['productInformation'] ?? state!.productInformation,
        deliveryInformation:
            updatedData['deliveryInformation'] ?? state!.deliveryInformation,
        endDate: updatedData['endDate'] ?? state!.endDate,
      );
    }
  }

  Future<void> deleteProduct(String productId) async {
    await _firestore.collection('products').doc(productId).delete();
    state = null;
  }
}
