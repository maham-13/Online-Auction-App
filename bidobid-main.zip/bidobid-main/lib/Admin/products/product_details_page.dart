import 'package:bidobid/models/product_model.dart';
import 'package:bidobid/Admin/products/provider/all_product_provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class ProductDetailsPage extends ConsumerStatefulWidget {
  final Product product;

  const ProductDetailsPage({super.key, required this.product});

  @override
  ConsumerState<ProductDetailsPage> createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends ConsumerState<ProductDetailsPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _priceController;
  late TextEditingController _categoryController;
  late TextEditingController _infoController;
  late TextEditingController _deliveryController;
  late TextEditingController _endDateController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.product.name);
    _priceController =
        TextEditingController(text: widget.product.baseprice.ceil().toString());
    _categoryController = TextEditingController(text: widget.product.category);
    _infoController =
        TextEditingController(text: widget.product.productInformation);
    _deliveryController =
        TextEditingController(text: widget.product.deliveryInformation);
    _endDateController =
        TextEditingController(text: widget.product.endDate.toDate().toString());
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _categoryController.dispose();
    _infoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final productNotifier = ref.read(productdetailsProvider.notifier);

    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        title: Text(
          'Update Product',
          style: GoogleFonts.bebasNeue(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () async {
              await productNotifier.deleteProduct(widget.product.productid);
              Navigator.pop(context); // Go back after deletion
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Product Name",
                  style: GoogleFonts.outfit(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                      hintText: "Product Name",
                      hintStyle: GoogleFonts.outfit(fontSize: 12),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0))),
                  validator: (value) =>
                      value!.isEmpty ? 'Enter product name' : null,
                ),
                const SizedBox(height: 8),
                Text(
                  "Base Price",
                  style: GoogleFonts.outfit(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                TextFormField(
                  controller: _priceController,
                  decoration: InputDecoration(
                      hintText: "Base Price",
                      hintStyle: GoogleFonts.outfit(fontSize: 12),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0))),
                  keyboardType: TextInputType.number,
                  validator: (value) => value!.isEmpty ? 'Enter price' : null,
                ),
                const SizedBox(height: 8),
                Text(
                  "Category",
                  style: GoogleFonts.outfit(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                TextFormField(
                  controller: _categoryController,
                  decoration: InputDecoration(
                      hintText: "Category",
                      hintStyle: GoogleFonts.outfit(fontSize: 12),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0))),
                  validator: (value) =>
                      value!.isEmpty ? 'Enter category' : null,
                ),
                const SizedBox(height: 8),
                Text(
                  "End Date",
                  style: GoogleFonts.outfit(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                TextField(
                  controller: _endDateController,
                  enableSuggestions: true,
                  readOnly: true,
                  decoration: InputDecoration(
                      suffixIcon: const Icon(
                        Icons.calendar_today_outlined,
                        color: Colors.black,
                      ),
                      hintText: 'End of Session',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0))
                      // fillColor: Colors.grey[200],
                      // filled: true,
                      ),
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2101));

                    if (pickedDate != null) {
                      String formattedDate =
                          DateFormat('yyyy-MM-dd').format(pickedDate);
                      setState(() {
                        _endDateController.text = formattedDate;
                      });
                    } else {
                      const snackBar =
                          SnackBar(content: Text('Date not added'));
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    }
                  },
                ),
                const SizedBox(height: 8),
                Text(
                  "Product Information",
                  style: GoogleFonts.outfit(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                TextFormField(
                  controller: _infoController,
                  decoration: InputDecoration(
                      hintText: "Product Information",
                      hintStyle: GoogleFonts.outfit(fontSize: 12),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0))),
                  validator: (value) =>
                      value!.isEmpty ? 'Enter product info' : null,
                ),
                const SizedBox(height: 8),
                Text(
                  "Delivery Information",
                  style: GoogleFonts.outfit(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                TextFormField(
                  controller: _deliveryController,
                  decoration: InputDecoration(
                      hintText: "Product Information",
                      hintStyle: GoogleFonts.outfit(fontSize: 12),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0))),
                  validator: (value) =>
                      value!.isEmpty ? 'Enter product Delivery info' : null,
                ),
                const SizedBox(height: 20),
                Align(
                  alignment: Alignment.center,
                  child: TextButton(
                    style: TextButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                        foregroundColor: Colors.white,
                        shape: const RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(12.0)))),
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        await productNotifier
                            .updateProduct(widget.product.productid, {
                          'name': _nameController.text,
                          'baseprice': double.parse(_priceController.text),
                          'category': _categoryController.text,
                          'productInformation': _infoController.text,
                          'deliveryInformation': _deliveryController.text,
                          'endDate': Timestamp.fromDate(
                              DateTime.parse(_endDateController.text)),
                        });
                        Navigator.pop(context); // Go back after update
                      }
                    },
                    child: const Text('Update Product'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
