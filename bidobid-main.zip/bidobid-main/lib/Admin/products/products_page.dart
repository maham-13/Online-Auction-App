import 'package:bidobid/Admin/products/product_details_page.dart';
import 'package:bidobid/Admin/products/provider/all_product_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class ProductsPage extends ConsumerWidget {
  const ProductsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productproviderAsync = ref.watch(productProvider);
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        title: Text(
          'Products',
          style: GoogleFonts.bebasNeue(color: Colors.white),
        ),
      ),
      body: productproviderAsync.when(
        data: (products) {
          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              return Card(
                color: Colors.white,
                child: ListTile(
                  leading: Image.network(
                    product.imageUrl,
                    width: 60,
                  ),
                  title: Text(product.name),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(product.baseprice.ceil().toString()),
                      Text(product.approvalStatus),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProductDetailsPage(
                              product: product,
                            ),
                          ));
                      // Call updateProduct with the product ID and updated data
                      // ref.read(productProvider.notifier).updateProduct(product.id, product.copyWith(name: 'New Name'));
                    },
                  ),
                ),
              );
            },
          );
        },
        error: (error, stackTrace) {
          return Text('Error: $error');
        },
        loading: () {
          return const CircularProgressIndicator();
        },
      ),
    );
  }
}
