import 'package:bidobid/Admin/activebids/activebid_page.dart';
import 'package:bidobid/Admin/productapproval/pendingapproval.dart';
import 'package:bidobid/Admin/products/products_page.dart';
import 'package:bidobid/Admin/users/user_page.dart';
import 'package:bidobid/pages/Authentication/login_%20page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'ADMIN PANEL',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        centerTitle: false,
      ),
      bottomNavigationBar: TextButton(
          onPressed: () {
            showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  title: const Icon(
                    Icons.logout_sharp,
                    color: Colors.deepPurple,
                    size: 80,
                  ),
                  content: Text(
                    "Are you sure you want to logout?",
                    style: GoogleFonts.outfit(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () async {
                        await FirebaseAuth.instance.signOut();
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const LoginPage(),
                          ),
                          (route) => false,
                        );
                      },
                      style: TextButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                          foregroundColor: Colors.white,
                          shape: const RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(12))),
                          minimumSize: const Size(double.infinity, 56)),
                      child: Text(
                        "Confirm",
                        style: GoogleFonts.outfit(
                          fontSize: 20,
                        ),
                      ),
                    )
                  ],
                );
              },
            );
          },
          child: Text(
            "Logout",
            style: GoogleFonts.outfit(
                fontSize: 20, color: Colors.white, fontWeight: FontWeight.w600),
          )),
      body: Container(
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(15),
          ),
        ),
        child: GridView(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2),
          children: [
            InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ProductsPage(),
                    ));
              },
              child: SizedBox(
                  width: double.infinity,
                  height: 150,
                  child: Card(
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          FontAwesomeIcons.productHunt,
                          color: Colors.blue,
                          size: 50,
                        ),
                        Text(
                          "Go to Products",
                          style: GoogleFonts.bebasNeue(
                            fontSize: 20,
                          ),
                        ),
                      ],
                    ),
                  )),
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return const UserPage();
                }));
              },
              child: SizedBox(
                  width: double.infinity,
                  height: 150,
                  child: Card(
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          FontAwesomeIcons.peopleArrows,
                          color: Colors.orange,
                          size: 50,
                        ),
                        Text(
                          "Go to Users",
                          style: GoogleFonts.bebasNeue(
                            fontSize: 20,
                          ),
                        ),
                      ],
                    ),
                  )),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return const PendingApprovalScreen();
                    },
                  ),
                );
              },
              child: SizedBox(
                  width: double.infinity,
                  height: 150,
                  child: Card(
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          FontAwesomeIcons.circleCheck,
                          color: Colors.green,
                          size: 50,
                        ),
                        Text(
                          "Product Approvals",
                          style: GoogleFonts.bebasNeue(
                            fontSize: 20,
                          ),
                        ),
                      ],
                    ),
                  )),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ActiveBidPage(),
                    ));
              },
              child: SizedBox(
                  width: double.infinity,
                  height: 150,
                  child: Card(
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          FontAwesomeIcons.tableCellsRowUnlock,
                          color: Colors.redAccent,
                          size: 50,
                        ),
                        Text(
                          "Active Bids",
                          style: GoogleFonts.bebasNeue(
                            fontSize: 20,
                          ),
                        ),
                      ],
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
