import 'dart:developer';

import 'package:bidobid/models/product_model.dart';
import 'package:bidobid/services/notification_service.dart';
import 'package:bidobid/widget/productvalue_widget.dart';
import 'package:bidobid/widget/title_widget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProductDetailsScreen extends StatefulWidget {
  final Product product;
  const ProductDetailsScreen({super.key, required this.product});

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  final NotificationServices notificationServices = NotificationServices();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  Future<void> updateApprovalStatus(String status, String ownerId) async {
    final data = await firestore.collection("users").doc(ownerId).get();
    final userdata = data.data();
    final devicetoken = userdata?["deviceToken"] ?? '';
    log(devicetoken);
    await FirebaseFirestore.instance
        .collection('products')
        .doc(widget.product.productid)
        .update({
      'approvalStatus': status,
      'isPopular': selectedStatus == 'IsPopular',
      'isRecommended': selectedStatus == 'IsRecommended',
    });
    if (devicetoken != "" && status == "approved") {
      await notificationServices.sendPushNotification(
          devicetoken,
          widget.product.name,
          "Great news! ${widget.product.ownerName} 🎉 Your product has been approved");
    } else if (devicetoken != "" && status == "rejected") {
      await notificationServices.sendPushNotification(
          devicetoken,
          widget.product.name,
          "🔴 Unfortunately, your product submission has been rejected");
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Product status updated to $status")),
    );

    Navigator.pop(context);
  }

  String? selectedStatus;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text("Products Details",
            style: GoogleFonts.bebasNeue(
              color: Colors.white,
              fontSize: 30,
            )),
        backgroundColor: Colors.deepPurple,
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(
              child: TextButton(
                onPressed: () {
                  if (selectedStatus == null) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Please select a status')));
                    return;
                  }
                  updateApprovalStatus("approved", widget.product.ownerId);
                },
                style: TextButton.styleFrom(
                  backgroundColor: Colors.green,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12.0))),
                ),
                child: Text(
                  "Approve",
                  style: GoogleFonts.bebasNeue(color: Colors.white),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextButton(
                onPressed: () =>
                    updateApprovalStatus("rejected", widget.product.ownerId),
                style: TextButton.styleFrom(
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12.0))),
                  backgroundColor: Colors.red,
                ),
                child: Text(
                  "Reject",
                  style: GoogleFonts.bebasNeue(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(12.0)),
                child: CachedNetworkImage(
                  fit: BoxFit.contain,
                  imageUrl: widget.product.imageUrl,
                  width: double.infinity,
                  height: 200,
                  fadeInCurve: Curves.bounceInOut,
                  fadeInDuration: const Duration(seconds: 3),
                  placeholder: (context, url) => Container(
                    height: 200,
                    width: double.infinity,
                    color: Colors.black.withOpacity(0.04),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const TitleWidget(
                title: 'Select Status',
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.deepPurple, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: DropdownButton<String>(
                  value: selectedStatus,
                  hint: const Text("Select Status"),
                  isExpanded: true,
                  underline: const SizedBox(),
                  items: const [
                    DropdownMenuItem(
                        value: 'IsPopular', child: Text('Is Popular')),
                    DropdownMenuItem(
                        value: 'IsRecommended', child: Text('Is Recommended')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      selectedStatus = value;
                    });
                  },
                ),
              ),
              const SizedBox(height: 16),
              const TitleWidget(
                title: 'Name',
              ),
              Productvaluewidget(
                value: widget.product.name,
                height: 56,
              ),
              const SizedBox(height: 8),
              // Text
              const TitleWidget(
                title: 'ID',
              ),
              Productvaluewidget(
                value: widget.product.productid,
                height: 56,
              ),

              const TitleWidget(
                title: 'Category',
              ),
              Productvaluewidget(
                value: widget.product.category,
                height: 56,
              ),

              const SizedBox(height: 8),
              const TitleWidget(
                title: 'Price',
              ),
              Productvaluewidget(
                value: "Rs ${widget.product.baseprice.ceil().toString()}",
                height: 56,
              ),
              const SizedBox(height: 8),
              const TitleWidget(
                title: 'Seller Email',
              ),
              Productvaluewidget(
                value: widget.product.ownerEmail,
                height: 56,
              ),

              const SizedBox(height: 8),
              const TitleWidget(
                title: 'Product Info',
              ),
              Productvaluewidget(
                value: widget.product.productInformation,
              ),

              const SizedBox(height: 8),
              const TitleWidget(
                title: 'Delivery Info',
              ),
              Productvaluewidget(
                value: widget.product.deliveryInformation,
                height: 56,
              ),

              const SizedBox(height: 16),

              // Buttons to Update Approval Status
            ],
          ),
        ),
      ),
    );
  }
}
