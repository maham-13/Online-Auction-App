import 'package:bidobid/models/product_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final productsApprovalProvider =
    StreamProvider.family<List<Product>, String>((ref, status) async* {
  yield* FirebaseFirestore.instance
      .collection('products')
      .where('approvalStatus', isEqualTo: status)
      .snapshots()
      .map((snapshot) =>
          snapshot.docs.map((e) => Product.fromSnapshot(e)).toList());
});
