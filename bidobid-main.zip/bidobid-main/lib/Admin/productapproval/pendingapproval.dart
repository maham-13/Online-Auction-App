import 'package:bidobid/Admin/productapproval/widget/product_info_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class PendingApprovalScreen extends ConsumerStatefulWidget {
  const PendingApprovalScreen({super.key});

  @override
  ConsumerState<PendingApprovalScreen> createState() =>
      _PendingApprovalScreenState();
}

class _PendingApprovalScreenState extends ConsumerState<PendingApprovalScreen>
    with SingleTickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        automaticallyImplyLeading: true,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          'Products Approvals',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
        bottom: TabBar(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          controller: tabController,
          dividerColor: Colors.white,
          indicatorColor: Colors.white,
          indicatorSize: TabBarIndicatorSize.tab,
          indicator: BoxDecoration(
              color: Colors.grey.withOpacity(0.4),
              borderRadius: BorderRadius.circular(4)),
          tabs: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Pending',
                style: GoogleFonts.bebasNeue(color: Colors.white, fontSize: 20),
              ),
            ),
            Text(
              'Approved',
              style: GoogleFonts.bebasNeue(color: Colors.white, fontSize: 20),
            ),
            Text(
              'Cancelled',
              style: GoogleFonts.bebasNeue(color: Colors.white, fontSize: 20),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: tabController,
        children: const [
          ProductList(approvalStatus: 'pending'),
          ProductList(approvalStatus: 'approved'),
          ProductList(approvalStatus: 'rejected'),
        ],
      ),
    );
  }
}
