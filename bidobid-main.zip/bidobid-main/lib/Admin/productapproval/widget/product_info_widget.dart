import 'package:bidobid/Admin/productapproval/provider/product_approval_provider.dart';
import 'package:bidobid/Admin/productapproval/widget/product_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ProductList extends ConsumerWidget {
  final String approvalStatus;
  const ProductList({super.key, required this.approvalStatus});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productList = ref.watch(productsApprovalProvider(approvalStatus));

    return productList.when(
      data: (products) {
        if (products.isEmpty) {
          return const Center(child: Text('No products found.'));
        }
        return ListView.builder(
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return ProductCard(product: product);
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) => Center(child: Text('Error: $error')),
    );
  }
}
