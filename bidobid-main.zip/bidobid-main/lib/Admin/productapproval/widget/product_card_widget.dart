import 'package:bidobid/models/product_model.dart';
import 'package:bidobid/Admin/productapproval/product_details_page.dart';
import 'package:flutter/material.dart';

class ProductCard extends StatefulWidget {
  final Product product;
  const ProductCard({super.key, required this.product});

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  // Future<void> updateApprovalStatus(String status) async {
  //   await FirebaseFirestore.instance
  //       .collection('products')
  //       .doc(widget.product.productid)
  //       .update({'approvalStatus': status});

  //   // ignore: use_build_context_synchronously
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(content: Text("Product status updated to $status")),
  //   );

  //   // Go back to previous screen after updating
  //   // ignore: use_build_context_synchronously
  //   Navigator.pop(context);
  // }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.all(8),
      child: ListTile(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  ProductDetailsScreen(product: widget.product),
            ),
          );
        },
        leading: Image.network(
          widget.product.imageUrl,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        ),
        title: Text(widget.product.name),
        subtitle: Text("Price: ${widget.product.baseprice}"),
        trailing: Text(widget.product.approvalStatus.toUpperCase(),
            style: TextStyle(
                color: widget.product.approvalStatus == 'approved'
                    ? Colors.green
                    : widget.product.approvalStatus == 'pending'
                        ? Colors.orange
                        : Colors.red)),
      ),
    );
  }
}
