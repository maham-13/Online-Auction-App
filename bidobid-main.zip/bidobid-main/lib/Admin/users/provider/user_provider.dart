import 'package:bidobid/models/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final alluserproviders = StateNotifierProvider<UserNotifier, List<UserModel>>(
  (ref) => UserNotifier(),
);

class UserNotifier extends StateNotifier<List<UserModel>> {
  UserNotifier() : super([]);
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  Future<void> fetchUsers() async {
    try {
      final data = await firestore.collection("users").get();
      final users = data.docs
          .map(
            (e) => UserModel.fromMap(e.data()),
          )
          .toList();

      state = users;
    } catch (e) {
      print("Erro $e");
    }
  }
}
