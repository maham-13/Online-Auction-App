import 'package:bidobid/Admin/users/provider/user_provider.dart';
import 'package:bidobid/models/user_model.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class UserViewPage extends ConsumerWidget {
  const UserViewPage({super.key, required this.user});
  final UserModel user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.read(alluserproviders.notifier).fetchUsers();

    final location = user.location;
    final dliveryinfo = user.deliveryInfo;
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(
        backgroundColor: Colors.deepPurple.withOpacity(0.5),

        iconTheme: const IconThemeData(color: Colors.white),
        // backgroundColor: ,
        title: Text(
          'User Profile',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
      ),
      body: Stack(
        children: [
          // Background Gradient

          Container(
            height: 250,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.deepPurple, Colors.white],
                begin: Alignment.topLeft,
                end: Alignment.topRight,
              ),
            ),
          ),

          // User Profile & Details
          Column(
            children: [
              const SizedBox(height: 100), // Space for AppBar & Gradient

              // Profile Image - Centered Stack

              const SizedBox(height: 20),

              // White Container for User Details
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 50),
                      Center(
                        child: Text(
                          user.name ?? '',
                          style: GoogleFonts.outfit(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Center(
                        child: Text(
                          user.email ?? '',
                          style: GoogleFonts.outfit(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.phone, color: Colors.deepPurple),
                          const SizedBox(width: 10),
                          Text(
                            user.phone,
                            style: GoogleFonts.outfit(fontSize: 16),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.email, color: Colors.deepPurple),
                          const SizedBox(width: 10),
                          Text(
                            user.email,
                            style: GoogleFonts.outfit(fontSize: 16),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.location_on,
                              color: Colors.deepPurple),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              "${location["city"] ?? ''} ${location["country"] ?? ''} ${location["postalcode"] ?? ''} ${location["subAdministrativeArea"] ?? ''}  ${location["thoroughfare"] ?? ''} ${location["street"] ?? ''} ${location["latitude"] ?? ''} ${location["longitude"] ?? ''} ",
                              style: GoogleFonts.outfit(fontSize: 16),
                              softWrap: true,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          const Icon(Icons.delivery_dining,
                              color: Colors.deepPurple),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              "${dliveryinfo["address"] ?? ''} ${dliveryinfo["city"] ?? ''} ${dliveryinfo["country"] ?? ''} ${dliveryinfo["zipcode"] ?? ''} ",
                              style: GoogleFonts.outfit(fontSize: 16),
                              softWrap: true,
                            ),
                          ),
                        ],
                      ),
                      user.isblock == false
                          ? Align(
                              alignment: Alignment.center,
                              child: TextButton(
                                onPressed: () async {
                                  // Handle block button tap
                                  await FirebaseFirestore.instance
                                      .collection("users")
                                      .doc(user.uid)
                                      .update({"isblock": true});
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content: Text(
                                              'User Blocked Successfully!')));
                                },
                                style: TextButton.styleFrom(
                                    backgroundColor: Colors.deepPurple,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                    )),
                                child: const Text("Block Account"),
                              ),
                            )
                          : Align(
                              alignment: Alignment.center,
                              child: TextButton(
                                onPressed: () async {
                                  // Handle block button tap
                                  await FirebaseFirestore.instance
                                      .collection("users")
                                      .doc(user.uid)
                                      .update({"isblock": false});
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content: Text(
                                              'User UnBlocked Successfully!')));
                                },
                                style: TextButton.styleFrom(
                                    backgroundColor: Colors.deepPurple,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                    )),
                                child: const Text("UnBlock Account"),
                              ),
                            )
                    ],
                  ),
                ),
              ),
            ],
          ),

          Positioned(
            top: 50,
            right: 0,
            left: 0,
            child: Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Circular Background
                  // const SizedBox(height: 100),
                  Container(
                    width: 120,
                    height: 120,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                  ),
                  // Profile Image
                  ClipOval(
                    child: user.userprofile != ""
                        ? CachedNetworkImage(
                            imageUrl: user.userprofile,
                            width: 110,
                          )
                        : Image.asset(
                            "assets/images/avater.png",
                            width: 110,
                            height: 110,
                            fit: BoxFit.cover,
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
