import 'package:bidobid/Admin/users/provider/user_provider.dart';
import 'package:bidobid/Admin/users/user_view_page.dart';
import 'package:bidobid/models/user_model.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class UserPage extends ConsumerWidget {
  const UserPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.read(alluserproviders.notifier).fetchUsers();

    // Fetch users only once when the widget is first built
    // ref.listen(alluserproviders, (previous, next) {});

    // if (ref.watch(alluserproviders).isEmpty) {
    //   userNotifier.fetchUsers();
    // }

    final userdata = ref.watch(alluserproviders);

    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        title: Text(
          'Users',
          style: GoogleFonts.bebasNeue(fontSize: 30, color: Colors.white),
        ),
      ),
      body: userdata.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              shrinkWrap: true,
              itemCount: userdata.length,
              itemBuilder: (context, index) {
                UserModel user = userdata[index];
                return Card(
                  color: Colors.white,
                  child: ListTile(
                    leading: SizedBox(
                      width: 40,
                      height: 40,
                      child: user.userprofile != ""
                          ? CachedNetworkImage(
                              imageUrl: user.userprofile,
                              fit: BoxFit.cover,
                            )
                          : Image.asset("assets/images/avater.png",
                              fit: BoxFit.cover),
                    ),
                    title: Text(
                      user.name, // Display actual user name
                      style: GoogleFonts.outfit(
                          fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user.phone, // Display actual phone number
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        Text(
                          user.email, // Display actual email
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                    trailing: IconButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => UserViewPage(
                                  user: user,
                                ),
                              ));
                        },
                        style: IconButton.styleFrom(
                            backgroundColor: Colors.deepPurple,
                            foregroundColor: Colors.white),
                        icon: const Icon(Icons.forward)),
                  ),
                );
              },
            ),
    );
  }
}
